﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System; // Для изменения размеров многомерного массива
using System.Text.RegularExpressions; // Для работы с текстом "Regex.Replace"

// Сохранение и загрузка в WebGL (на сервер) ///////////////////////////////////////
//using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;

// Сохранение и загрузка в WebGL ///////////////////////////////////////
using System.Runtime.Serialization;
////////////////////////////////////////////////////////////////////////

public class ListView : MonoBehaviour {					
	private int ListViewSelected, // Номер выделенной таблицы
	Count_ListView,Number_ListView,tNumOfColumn0,tNumOfItem0,ClickedOnList, 
	MovedOnListItem,MovedOnListColumn,HintByMove,selGridInt,selGridInt_check,
	MouseRightClick,CMoutOfTable,MaxColumnCount,MaxItemCount, EditSomeField,
	PressedEnter1,PressedTab1, Show_Hide_count;
	private int [] tNumOfColumn,tNumOfItem,MouseDoubleClick,MouseLeftClick,
	CMchanged,CMbutton,LPartVisibleColumn,
	ListViewItemHint, // Номер ячейки для отображения подсказки
	ListViewColumnHint; // Номер колонки для отображения подсказки
	private int [,] ChangeVariables;
	private float timeShowHint, // Показывать подсказку с задержкой
	timeMouseWheel;
	private float [] timeLeft, // Засечь время, чтобы не перескакивать через ряды
	timeMouseClick,timeKeyPressed; // Время нажатий клавиш
	private float [,] tColumnProperty, // 0-кол-во колонок, 1-отступ по Y между колонкой и кнопкой
	tItemProperty, // 0-кол-во рядов, 1-отступ по X между рядами, 2-отступ по Y между кнопками
	HV_Scroll1, // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара)
	MainRect_float; // 0-X, 1-Y, 2-Width, 3-Height скролла (границ) компонента ListView
	private float [,,] cStartSizes, // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
	iStartSizes, // Указанные размеры рядов (0-высота ряда)
	cStartSizes_c,iStartSizes_c;
	private bool FirstCreateGUI, // false-если первый цикл GUI
	otherbutton1,othertext1;
	private bool [] EditInField, // true-если редактируется текст в ячейке
	EditInColumn, // true-если редактируется текст в колонке
	Show_Hide; // Массив со свойствами что показывать
	private string columnString;
	private string [] ChangingText,selStrings,
	LoadTables, SaveTables, Show_Hide_name;
	private string [,] tNameOfColumns, tNameOfColumns_c; // Названия колонок
	private string [,,] tNameOfItems, tNameOfItems_c; // Названия ячеек
	private Rect HintItemSize, HintColumnSize, CMrectangle; // Позиция, размеры подсказки
	private Rect [] Active_ListView, // Позиция, размеры квадрата с активным "ListView"
	rect_AddDelRowColumn,rect_SaveLoad;
	private Rect [,] Rect_Scroll; // 0-Ширина и высота компонента ListView с ползунками, 1-Ширина и высота компонента ListView без ползунков, 2-Общая ширина, высота со всеми кнопками и колонками
	private Rect [,,] tColumnRect, // 0-позиция колонки, 1-позиция кнопки X
	tItemRect, // 0-позиция ряда, 1-позиция кнопки Y
	tColumnRect_c,tItemRect_c;
	private GUIStyle GuiHintColumnStyle, GuiHintItemStyle, CMStyle, CMbuttonStyle;
	private GUIStyle [] Show_Hide_style;
	private GUIStyle [,] GuiArrStyle;
	private Vector2 SimpleVector, Show_Hide_scroll;
	private Vector2 [] scrollPosition,scrollPosition_check, // The position on of the scrolling viewport
	clickPosition, TableSize_wh;
	private float Time_ctrl_c_ctrl_v;
	private string PasteTextStr1 = "";
	private string CopyedText1;
	private int[] CopyedPos1 = new int[2];

	////////////////////////////////////////////////////////////////////////
	private int Copy_MaximumOfChanges,Copy_CountOfChanges,Copy_CountOfChangesF,
	Copy_NumOfChange, Copy_ArrayChanged;
	private int [] Copy_MaximumOfItems,Copy_MaximumOfColumns,
	Copy_Count_ListView,Copy_ListViewSelected,Copy_tNumOfItem,Copy_tNumOfColumn;
	private float [,] Copy_tItemProperty,Copy_tColumnProperty;
	private string [,] Copy_tNameOfColumns;
	private string [,,] Copy_tNameOfItems;
	private Rect [,,] Copy_tColumnRect, Copy_tItemRect;
	private float [,,] Copy_cStartSizes, Copy_iStartSizes;
	////////////////////////////////////////////////////////////////////////

	// (Не обязательно) Для отображения кириллицы в WebGL (Перенести файл шрифт Windows типа "Arial" в папку "Assets" и прикрепить к переменной)
	public Font TextFontStyle;

	// Работать через WebGL //////////////////////////////////////////////////
	#if UNITY_WEBGL
	[DllImport("__Internal")] // Определить функцию JavaScript
	private static extern void getImageFromBrowser(string objectName, string callbackFuncName);
	[DllImport("__Internal")] 
	private static extern void SaveFile(string str, string strName);
	[DllImport("__Internal")] 
	private static extern void copyStringToClipboard(string str);
	[DllImport("__Internal")] 
	private static extern void pasteStringFromClipboard(string objectName, string str);
	#endif
	//////////////////////////////////////////////////////////////////////////



	void Start() {			
		CreateOptions (); // Установить свойства компонента ListView
	}		


	void OnGUI() {

		// Скопировать скрипт в буфер обмена
		if (GUI.Button (new Rect (10, 10, 300, 40), "Copy script (C# Unity3d)", GUI.skin.button)) {
			CopyToBuffer(SavingText.Savingtex1+
				SavingText2.Savingtex2+SavingText3.Savingtex3); // Скопировать в буфер обмена
		}

		// Сохранение и загрузка в WebGL ///////////////////////////////////////
		if (GUI.Button (rect_SaveLoad [0], "Save", GUI.skin.button)) {
			SaveDataWebGl1 (); // Сохранить информацию WebGl
		}

		if (GUI.Button (rect_SaveLoad [1], "Load", GUI.skin.button)) {
			//LoadDataWebGl1 (); // Загрузить информацию WebGl
			#if UNITY_WEBGL
			getImageFromBrowser(gameObject.name, "LoadDataWebGl1"); // Обратиться к функции JavaScript "getImageFromBrowser" и получить результат в функцию C# "ReceiveImage"
			#else
			Debug.LogError("Not implemented in this platform");
			#endif
		}
		////////////////////////////////////////////////////////////////////////

		ChangeTextByWheel (); // Поменять текст колесиком мыши

		SaveTables [0] = GUI.TextField(rect_SaveLoad [2], SaveTables [0], GUI.skin.textField);
		LoadTables [0] = GUI.TextField(rect_SaveLoad [3], LoadTables [0], GUI.skin.textField);

		if ((LoadTables [0] != LoadTables [1]) | (SaveTables [0] != SaveTables [1]))
		{		
			LoadTables [0] = Regex.Replace(LoadTables [0], "[^0-9]", ""); // Только числа
			SaveTables [0] = Regex.Replace(SaveTables [0], "[^0-9]", ""); // Только числа
			LoadTables [1] = LoadTables [0];
			SaveTables [1] = SaveTables [0];
		}

		MakeStyle (); // Установить стили компонентов

		if (PressedEnter1 > 0) {			
			if (Event.current.keyCode != KeyCode.Return) {	
				PressedEnter1 = 0;
			}
		}

		if (PressedTab1 > 0) {			
			if (Event.current.keyCode != KeyCode.Tab) {	
				PressedTab1 = 0;
			}
		}

		// По нажатию "Tab" (поменять активный "ListView")
		if ((PressedTab1==0) & (Event.current.keyCode == KeyCode.Tab)) {
			PressedTab1 = 1;
			if (ListViewSelected > -1) {
				if (Time.fixedTime > timeKeyPressed [2]) {
					timeKeyPressed [2] = Time.fixedTime + 0.5f;
					ListViewSelected = ListViewSelected + 1;
					if (ListViewSelected > Count_ListView - 1) {
						ListViewSelected = 0;
					}
					ShowHintAfterMove (); // Показывать подсказку после перемещения клавишами	
				}
			}
		}		

		if (GUI.Button(rect_AddDelRowColumn [0], "- C", GUI.skin.button))
		{
			DeleteColumnLV (); // Удалить колонку ListView	
		}

		if (GUI.Button(rect_AddDelRowColumn [1], "+ C", GUI.skin.button))
		{ 
			AddColumnLV (); // Добавить колонку ListView					
		}			

		if (GUI.Button(rect_AddDelRowColumn [2], "- R", GUI.skin.button))
		{
			DeleteRowLV (); // Удалить ряд ListView
		}	

		if (GUI.Button(rect_AddDelRowColumn [3], "+ R", GUI.skin.button))
		{ 
			AddRowLV (); // Добавить ряд ListView					
		}			

		// Чекбоксы
		Show_Hide_scroll = GUI.BeginScrollView (rect_AddDelRowColumn [4], 
			Show_Hide_scroll, rect_AddDelRowColumn [5]);		
		GUI.Label (rect_AddDelRowColumn [5], "", Show_Hide_style [0]);	// Фон чекбоксов
		for (int i = 0; i < Show_Hide_count; i++) {
			Show_Hide [i] = GUI.Toggle (new Rect (5, 
				i*18+5, 380, 18), Show_Hide [i], new GUIContent(
					Show_Hide_name [i], Show_Hide_name [i])
				, Show_Hide_style [1]);
		}
		GUI.EndScrollView ();	

		// Подсказка для чекбоксов
		GUI.Label(new Rect(rect_AddDelRowColumn [4].xMax+10, 
			rect_AddDelRowColumn [4].y, 150, rect_AddDelRowColumn [4].height), 
			GUI.tooltip, Show_Hide_style [2]);

		//====================== СОЗДАТЬ LISTVIEW1	======================================================================================				
		ClickedOnList = -1; // Если -1, то ни один ListView не выделен, 1-ListView выделен
		MovedOnListItem = -1; // Если -1, то ни на одну ячейку ListView не наведен курсор, 1-курсор над ячейкой ListView
		MovedOnListColumn = -1; // Если -1, то ни на одну колонку ListView не наведен курсор, 1-курсор над колонкой ListView
		for (Number_ListView = 0; Number_ListView <= Count_ListView - 1; Number_ListView++) {
			GUI.Box (Rect_Scroll [Number_ListView, 1], "", GuiArrStyle [Number_ListView, 0]);							
			GUI.Label (Rect_Scroll [Number_ListView, 0], "", GuiArrStyle [Number_ListView, 1]);	// Фон колонок
			GUI.Label (Rect_Scroll [Number_ListView, 2], "", GuiArrStyle [Number_ListView, 13]);	// Фон ячеек

			if (ListViewSelected == Number_ListView) { // Если выделенный ListView
				GUI.Label (Active_ListView [Number_ListView], "", GuiArrStyle [Number_ListView, 11]);	// Квадрат с активным "ListView"
			}
			else GUI.Label (Active_ListView [Number_ListView], "", GuiArrStyle [Number_ListView, 12]);	// Квадрат с не активным "ListView"		

			scrollPosition [Number_ListView] = 
				GUI.BeginScrollView (Rect_Scroll [Number_ListView, 1], 
					scrollPosition [Number_ListView], Rect_Scroll [Number_ListView, 3]);

			CheckListView (); // Проверка взаимодействия с ListView

			if (scrollPosition_check [Number_ListView] != scrollPosition [Number_ListView])
				VisibleArea (); // Определить кнопки в видимой области	

			// Создавать кнопки только в области прорисовки
			for (int i = ChangeVariables [Number_ListView, 0]; i <= ChangeVariables [Number_ListView, 1]; i++) {
				// Разделитель колонок						
				GUI.Label (new Rect (tColumnRect [Number_ListView, i, 0].x, scrollPosition [Number_ListView].y, tColumnRect [Number_ListView, i, 0].width, Rect_Scroll [Number_ListView, 1].height), "", GuiArrStyle [Number_ListView, 5]);	

				for (int j = ChangeVariables [Number_ListView, 2]; j <= ChangeVariables [Number_ListView, 3]; j++) {
					// Не отрисовывать выделенную кнопку (чтобы можно было вводить текст)
					if ((i != tNumOfColumn [Number_ListView]) | (j != tNumOfItem [Number_ListView])) {
						// Убирать нижние ячейки во время редактирования текста	
						if (((Rect_Scroll [Number_ListView, 5].xMax < tColumnRect [Number_ListView, i, 1].x) |
						    (Rect_Scroll [Number_ListView, 5].x > tColumnRect [Number_ListView, i, 1].x)) |
						    ((Rect_Scroll [Number_ListView, 5].yMax < tItemRect [Number_ListView, j, 1].y) |
						    ((!EditInColumn [Number_ListView]) & (Rect_Scroll [Number_ListView, 5].y >
						    tItemRect [Number_ListView, j, 1].y)))) {

							if (LPartVisibleColumn [Number_ListView] < 
								tItemProperty[Number_ListView, 1]+8) { // Если левая часть колонки с номером в пределах видимости
								if (i == ChangeVariables [Number_ListView, 0]) { // Показывать номер ряда в левой колонке
									columnString = "|" + j.ToString () + "| ";
								} else columnString = "";										
							} else { // Показывать номер ряда в левой колонке 								
								if (i == ChangeVariables [Number_ListView, 0]+1) { // Показывать номер ряда в левой колонке 						
									columnString = "|" + j.ToString () + "| ";
								} else columnString = "";	
							}					

							// Выделить ряд цветом
							if ((Show_Hide [1] == true) & (tNumOfItem [Number_ListView] == j)) {
								GUI.Button (new Rect (tColumnRect [Number_ListView, i, 1].x, tItemRect [Number_ListView, j, 1].y, 
									tColumnRect [Number_ListView, i, 1].width, tItemRect [Number_ListView, j, 1].height), columnString + tNameOfItems [Number_ListView, i, j], GuiArrStyle [Number_ListView, 7]);
							} else
								// Выделить колонку цветом
								if ((Show_Hide [2] == true) & (tNumOfColumn [Number_ListView] == i)) {
								GUI.Button (new Rect (tColumnRect [Number_ListView, i, 1].x, tItemRect [Number_ListView, j, 1].y, 
									tColumnRect [Number_ListView, i, 1].width, tItemRect [Number_ListView, j, 1].height), columnString + tNameOfItems [Number_ListView, i, j], GuiArrStyle [Number_ListView, 8]);
							} else {
								GUI.Button (new Rect (tColumnRect [Number_ListView, i, 1].x, tItemRect [Number_ListView, j, 1].y, 
									tColumnRect [Number_ListView, i, 1].width, tItemRect [Number_ListView, j, 1].height), columnString + tNameOfItems [Number_ListView, i, j], GuiArrStyle [Number_ListView, 3]);
							}						
						}					
					}
				}						
			}				

			if (EditInField [Number_ListView]) { // Если можно редактировать ячейку

				if (ListViewSelected == Number_ListView) { // Если выделенный ListView
					// По нажатию "Esc" (вернуть первоначальный текст)
					if (Event.current.keyCode == KeyCode.Escape) { 
						if (EditInField [Number_ListView] == true) { // Вернуть не измененный текст ячейки
							tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]] = ChangingText [Number_ListView];
						}
						EditInField [Number_ListView] = false;
					}

					// По нажатию "Enter" (сохранить текст)
					if ((PressedEnter1==0) & (Event.current.keyCode == KeyCode.Return)) {	
						PressedEnter1 = 1;
						if (Time.fixedTime > timeKeyPressed [1]) {
							timeKeyPressed [1] = Time.fixedTime + 0.5f;
							if ((Show_Hide [5] == false) & (EditInField [Number_ListView] == true)) { // Вернуть не измененный текст ячейки
								tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]] = ChangingText [Number_ListView];
							} else if (EditInField [ListViewSelected]) {									
								Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
									tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
							}
							EditInField [Number_ListView] = false;
							ShowHintAfterMove (); // Показывать подсказку после перемещения клавишами	
						}							
					} else if ((Event.current.keyCode == KeyCode.LeftControl) |
						(Event.current.keyCode == KeyCode.RightControl)) { // Если нажат левый или правый "Ctrl"
						//SaveTables [0] = "0";
						Time_ctrl_c_ctrl_v = Time.fixedTime+0.2f;
						GUIUtility.systemCopyBuffer = ""; // Убрать текст из внутреннего буфера обмена
					} else if ((Event.current.keyCode == KeyCode.C) | 
						(Event.current.keyCode == KeyCode.X)) { // Если нажата клавиша "C" или "X"
						if (Time.fixedTime <= Time_ctrl_c_ctrl_v) {	// Если "0.2" секунд назад был нажат левый или правый "Ctrl"

						 TextEditor te = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);
						 if (te != null){
						  //print(te.SelectedText);
						  CopyToBuffer(te.SelectedText); // Скопировать в буфер обмена															
						 }
							//CopyToBuffer(GUIUtility.systemCopyBuffer); // Скопировать в буфер обмена	
						}
					} else if (Event.current.keyCode == KeyCode.V) { // Если нажата клавиша "V"												
						if (Time.fixedTime <= Time_ctrl_c_ctrl_v) {	// Если "0.2" секунд назад был нажат левый или правый "Ctrl"														
							CopyedText1 = tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]];
							TextEditor te = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);
							if (te != null){
								CopyedPos1[0] = te.cursorIndex; // Позиция курсора
								CopyedPos1[1] = te.selectIndex; // Позиция курсора, до какого символа выделен текст
							}

							//print (ChangingText [Number_ListView] + "\n" + tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]]);
							GUIUtility.systemCopyBuffer = ""; // Убрать текст из внутреннего буфера обмена
							PasteTextStr1 = "=|" + Number_ListView.ToString () + "|" + tNumOfColumn [Number_ListView].ToString () + "|" + tNumOfItem [Number_ListView].ToString () + "|";
							//PasteFromBuffer (s2); // Вставить из буфера обмена
							Time_ctrl_c_ctrl_v = 0;
						}
					}


					if (((Time.fixedTime < timeKeyPressed [0])) | 
						(Time.fixedTime < timeKeyPressed [1]) | 
						(Time.fixedTime < timeKeyPressed [2])) { // Если ранее был нажат "Enter"						
						GUI.FocusControl ("EditField" + ListViewSelected.ToString ()); // Сделать активным элемент GUI под именем "EditField+Number_ListView.ToString()"					
					}
				}					

				float hh1 = 0;

				GUI.SetNextControlName ("EditField" + Number_ListView.ToString ()); // Задать имя нижнему элементу

				if (Show_Hide [6] == true) { // Увеличивать редактируемую ячейку
					hh1 = GuiArrStyle [Number_ListView, 2].CalcHeight (new GUIContent (tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]]),
						tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].width); // Высота текста зная ширину текстового поля					
					if (hh1 < tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].height)
						hh1 = tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].height;
					Rect_Scroll [Number_ListView, 5] = new Rect (tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].x, 
						tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y, 
						tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].width, hh1);	
					tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]] = GUI.TextField (Rect_Scroll [Number_ListView, 5], 
						tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]], GuiArrStyle [Number_ListView, 2]); // Редактируемая ячейка				
				} else {
					tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]] = 
						GUI.TextField (new Rect (tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].x, 
							tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y, 
							tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].width, 
							tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].height), 
							tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]], GuiArrStyle [Number_ListView, 2]); // Редактируемая ячейка				
				}	

				if (GUI.changed) {
					GUIUtility.systemCopyBuffer = ""; // Убрать текст из внутреннего буфера обмена
					if (PasteTextStr1.Length > 0) {
					 PasteFromBuffer (PasteTextStr1); // Вставить из буфера обмена
					 PasteTextStr1 = "";
					}
					//print ("123");
				}

				// Увеличить размеры таблицы если текст выходит за границы
				if ((Show_Hide [6] == true) & (TableSize_wh[Number_ListView].y <
					tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y + hh1)) {
					Rect_Scroll [Number_ListView, 3] = new Rect (
						Rect_Scroll [Number_ListView, 3].x, 
						Rect_Scroll [Number_ListView, 3].y,
						Rect_Scroll [Number_ListView, 3].width, 
						tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y + 
						hh1 + tItemProperty[Number_ListView, 2] + 5);
				} 
				// Вернуть размеры таблицы если текст в пределах границ
				else if (Rect_Scroll [Number_ListView, 3].height != 
					TableSize_wh[Number_ListView].y) {
					Rect_Scroll [Number_ListView, 3] = new Rect (
						Rect_Scroll [Number_ListView, 3].x, 
						Rect_Scroll [Number_ListView, 3].y,
						TableSize_wh[Number_ListView].x, 
						TableSize_wh[Number_ListView].y);
				}
			} else { // Если нельзя редактировать
				if (!EditInColumn [Number_ListView]) // Если нельзя редактировать колонку
				Rect_Scroll [Number_ListView, 5] = new Rect (0, 0, 0, 0);

				GUI.SetNextControlName ("EditField" + Number_ListView.ToString ()); // Задать имя нижнему элементу

				float hh1 = 0;

				if (Show_Hide [7] == true) { // Увеличивать выделенную ячейку
					string s = "|" + tNumOfItem [Number_ListView].ToString () + "| " + tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]];
					hh1 = GuiArrStyle [Number_ListView, 6].CalcHeight (new GUIContent (s),
						tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].width); // Высота текста зная ширину текстового поля
					if (hh1 < tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].height)
						hh1 = tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].height;

					// Убирать ячейку во время редактирования текста колонки
					if ((!EditInColumn [Number_ListView]) | (Rect_Scroll [Number_ListView, 5].yMax < tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y)) {
						GUI.Label (new Rect (tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].x, 
							tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y, 
							tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].width, 
							hh1), s, GuiArrStyle [Number_ListView, 6]); // Выделенная ячейка									
					}
				} else {
					// Убирать ячейку во время редактирования текста колонки
					if ((!EditInColumn [Number_ListView]) | (Rect_Scroll [Number_ListView, 5].yMax < tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y)) {
						GUI.Label (new Rect (tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].x, 
							tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y, 
							tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 1].width, 
							tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].height), 
							tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]], GuiArrStyle [Number_ListView, 6]); // Выделенная ячейка						
					}
				}

				// Увеличить размеры таблицы если текст выходит за границы
				if ((Show_Hide [7] == true) & (TableSize_wh[Number_ListView].y <
					tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y + hh1)) {
					Rect_Scroll [Number_ListView, 3] = new Rect (
						Rect_Scroll [Number_ListView, 3].x, 
						Rect_Scroll [Number_ListView, 3].y,
						Rect_Scroll [Number_ListView, 3].width, 
						tItemRect [Number_ListView, tNumOfItem [Number_ListView], 1].y + 
						hh1 + tItemProperty[Number_ListView, 2] + 5);
				} 
				// Вернуть размеры таблицы если текст в пределах границ
				else if (Rect_Scroll [Number_ListView, 3].height != 
					TableSize_wh[Number_ListView].y) {
					Rect_Scroll [Number_ListView, 3] = new Rect (
						Rect_Scroll [Number_ListView, 3].x, 
						Rect_Scroll [Number_ListView, 3].y,
						TableSize_wh[Number_ListView].x, 
						TableSize_wh[Number_ListView].y);
				}
					
				if (ListViewSelected == Number_ListView) { // Если выделенный ListView
					if (((Time.fixedTime < timeKeyPressed [0])) | 
						(Time.fixedTime < timeKeyPressed [1]) | 
						(Time.fixedTime < timeKeyPressed [2])) { // Если ранее был нажат "Enter"						
						GUI.FocusControl ("EditField" + ListViewSelected.ToString ()); // Сделать активным элемент GUI под именем "EditField+Number_ListView.ToString()"					
					}

					// По нажатию "Esc" (отключить подсказку)
					if (Event.current.keyCode == KeyCode.Escape) { 
						MouseRightClick = 0; // 1-нажата правая кнопка мыши, 0-кнопка мыши не нажата
						CMrectangle = new Rect(0,0,0,0);

						if (HintByMove == 1) { // Если подсказка от клавиатуры
							ListViewItemHint [0] = -1; // Номер ListView
							ListViewItemHint [1] = -1; // Номер колонки для отображения подсказки
							ListViewItemHint [2] = -1; // Номер ряда для отображения подсказки					
							ListViewColumnHint [0] = -1; // Номер ListView
							ListViewColumnHint [1] = -1; // Номер колонки для отображения подсказки						
						}
					}

					// По нажатию "Enter" (редактировать текст)
					if ((PressedEnter1==0) & (Event.current.keyCode == KeyCode.Return)) {
						PressedEnter1 = 1;
						if ((!EditInColumn [Number_ListView]) & 
							(Time.fixedTime > timeKeyPressed [1])) {
							timeKeyPressed [1] = Time.fixedTime + 0.5f;
							ChangingText [Number_ListView] = tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]]; // Запомнить не измененный текст						
							if (Show_Hide [4] == true) { // Возможность редактировать ячейку								
								EditSomeField = 1;
								EditInField [Number_ListView] = true;
								CMchanged [ListViewSelected] = 1;
								Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
									tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
							}
						}
					}
				}
			}

			// Названия Columns, колонки
			for (int i = 0; i < tColumnProperty [Number_ListView, 0]; i++) {
				// Не прорисовывать редактируемую колонку
				if ((!EditInColumn [Number_ListView]) | (i != tNumOfColumn [Number_ListView])) {
					// Выделить колонку цветом
					if ((Show_Hide [3] == true) & (tNumOfColumn [Number_ListView] == i)) {
						GUI.Label (
							new Rect (tColumnRect [Number_ListView, i, 2].x, Mathf.RoundToInt (scrollPosition [Number_ListView].y), 
							tColumnRect [Number_ListView, i, 2].width, tColumnRect [Number_ListView, i, 2].height), tNameOfColumns [Number_ListView, i], GuiArrStyle [Number_ListView, 9]);							
					} else {					
						GUI.Label (
							new Rect (tColumnRect [Number_ListView, i, 2].x, Mathf.RoundToInt (scrollPosition [Number_ListView].y), 
							tColumnRect [Number_ListView, i, 2].width, tColumnRect [Number_ListView, i, 2].height), tNameOfColumns [Number_ListView, i], GuiArrStyle [Number_ListView, 4]);							
					}
				}
			}				

			if (EditInColumn [Number_ListView]) { // Если можно редактировать колонку

				if (ListViewSelected == Number_ListView) { // Если выделенный ListView					
					// По нажатию "Esc" (вернуть первоначальный текст)
					if (Event.current.keyCode == KeyCode.Escape) { 						
						if (EditInColumn [Number_ListView] == true) { // Вернуть не измененный текст колонки
							tNameOfColumns [Number_ListView, tNumOfColumn [Number_ListView]] = ChangingText [Number_ListView];
						}
						EditInColumn [Number_ListView] = false;
					}

					// По нажатию "Enter" (сохранить текст)
					if (Event.current.keyCode == KeyCode.Return) {						
						if (Time.fixedTime > timeKeyPressed [1]) {
							timeKeyPressed [1] = Time.fixedTime + 0.5f;
							SaveChanges1 ();
							EditInColumn [Number_ListView] = false;
						}
					} else if ((Event.current.keyCode == KeyCode.LeftControl) |
						(Event.current.keyCode == KeyCode.RightControl)) { // Если нажат левый или правый "Ctrl"
						//SaveTables [0] = "0";
						Time_ctrl_c_ctrl_v = Time.fixedTime+0.2f;
						GUIUtility.systemCopyBuffer = ""; // Убрать текст из внутреннего буфера обмена
					} else if ((Event.current.keyCode == KeyCode.C) | 
						(Event.current.keyCode == KeyCode.X)) { // Если нажата клавиша "C" или "X"
						if (Time.fixedTime <= Time_ctrl_c_ctrl_v) {	// Если "0.2" секунд назад был нажат левый или правый "Ctrl"
							TextEditor te = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);
							if (te != null){
							 //print(te.SelectedText);
							 CopyToBuffer(te.SelectedText); // Скопировать в буфер обмена	
							}
							//CopyToBuffer(GUIUtility.systemCopyBuffer); // Скопировать в буфер обмена	
						}
					} else if (Event.current.keyCode == KeyCode.V) { // Если нажата клавиша "V"												
						if (Time.fixedTime <= Time_ctrl_c_ctrl_v) {	// Если "0.2" секунд назад был нажат левый или правый "Ctrl"														
							CopyedText1 = tNameOfColumns [Number_ListView, tNumOfColumn [Number_ListView]];
							TextEditor te = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);
							if (te != null){
								CopyedPos1[0] = te.cursorIndex; // Позиция курсора
								CopyedPos1[1] = te.selectIndex; // Позиция курсора, до какого символа выделен текст
							}
							//print (ChangingText [Number_ListView] + "\n" + tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]]);
							GUIUtility.systemCopyBuffer = ""; // Убрать текст из внутреннего буфера обмена
							PasteTextStr1 = "=|" + Number_ListView.ToString () + "|" + tNumOfColumn [Number_ListView].ToString () + "|0|";
							//PasteFromBuffer (s2); // Вставить из буфера обмена
							Time_ctrl_c_ctrl_v = 0;
						}
					}
				}

				Rect_Scroll [Number_ListView, 5] = new Rect (
					tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 2].x, 
					Mathf.RoundToInt (scrollPosition [Number_ListView].y), 
					tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 2].width, 
					tColumnRect [Number_ListView, tNumOfColumn [Number_ListView], 2].height);
					
				tNameOfColumns [Number_ListView, tNumOfColumn [Number_ListView]] = 
						GUI.TextField (Rect_Scroll [Number_ListView, 5], 
					tNameOfColumns [Number_ListView, tNumOfColumn [Number_ListView]], GuiArrStyle [Number_ListView, 10]); // Редактируемая колонка							

				if (GUI.changed) {
					GUIUtility.systemCopyBuffer = ""; // Убрать текст из внутреннего буфера обмена
					if (PasteTextStr1.Length > 0) {
					 PasteFromBuffer (PasteTextStr1); // Вставить из буфера обмена
					 PasteTextStr1 = "";
					}
					//print ("123");
				}
			}

			// End the scroll view that we began above.
			GUI.EndScrollView ();	
		}
		//=====================================================================================================================================						

		if ((Show_Hide[10]==true) & (ListViewColumnHint [1] > -1)) { // Если на колонку ListView наведен курсор
			if (Time.fixedTime > timeShowHint) { // Показывать подсказку с задержкой				
				GUI.Label (HintColumnSize, tNameOfColumns [ListViewColumnHint [0], ListViewColumnHint [1]], GuiHintColumnStyle);
			}
		}

		if ((Show_Hide[0]==true) & (ListViewItemHint [1] > -1)) { // Если на ячейку ListView наведен курсор
			if (Time.fixedTime > timeShowHint) { // Показывать подсказку с задержкой				
				GUI.Label (HintItemSize, tNameOfItems [ListViewItemHint [0], ListViewItemHint [1], ListViewItemHint [2]], GuiHintItemStyle);
			}
		}

		if (MouseRightClick > 0) {			
			GUI.Label (CMrectangle, "", CMStyle); // Фон контекстного меню
			selGridInt = GUI.SelectionGrid (CMrectangle, selGridInt, selStrings, 1, CMbuttonStyle); // Кнопки контекстного меню
		}			
	}				


	public bool AddRowLV () { // Добавить ряд ListView	
		if (ListViewSelected > -1) {
			// Сохранить таблицы перед изменением
			Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
				tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"

			// Таблица
			string[,,] tNameOfItems1 = new string[Count_ListView, MaxColumnCount, MaxItemCount];
			//Rect[,,] tColumnRect1 = new Rect[Count_ListView, MaxColumnCount , 3];
			Rect[,,] tItemRect1 = new Rect[Count_ListView, MaxItemCount , 2];
			//float[,,] cStartSizes1 = new float[Count_ListView, MaxColumnCount , 2]; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
			float[,,] iStartSizes1 = new float[Count_ListView, MaxItemCount , 1]; // Указанные размеры рядов (0-высота ряда)

			for (int o = 0; o < Count_ListView; o++) {
				for (int i = 0; i < tItemProperty [o, 0]; i++) {
					for (int j = 0; j < tColumnProperty [o, 0]; j++) {
						tNameOfItems1 [o, j, i] = tNameOfItems [o, j, i];
					}
					tItemRect1 [o, i, 0] = tItemRect [o, i, 0];
					tItemRect1 [o, i, 1] = tItemRect [o, i, 1];
					iStartSizes1 [o, i, 0] = iStartSizes [o, i, 0];
				}
			}

			tItemProperty [ListViewSelected, 0] = tItemProperty [ListViewSelected, 0] + 1;

			if (tItemProperty [ListViewSelected, 0] > MaxItemCount) {
				MaxItemCount = Mathf.FloorToInt (tItemProperty [ListViewSelected, 0]); // Максимальное количество рядов

				//tColumnRect = new Rect[Count_ListView, MaxColumnCount , 3]; // 0-позиция колонки, 1-позиция кнопки X, 2-позиция текста в колонке
				tItemRect = new Rect[Count_ListView, MaxItemCount , 2]; // 0-позиция ряда, 1-позиция кнопки Y
				//cStartSizes = new float[Count_ListView, MaxColumnCount , 2]; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
				iStartSizes = new float[Count_ListView, MaxItemCount , 1]; // Указанные размеры рядов (0-высота ряда)
				tNameOfItems = new string[Count_ListView, MaxColumnCount, MaxItemCount];
			}

			int k;

			for (int o = 0; o < Count_ListView; o++) {			
				if (o == ListViewSelected) {	
					k = 0;
					for (int i = 0; i < tItemProperty [o, 0] - 1; i++) {
						if (k == tNumOfItem [ListViewSelected]) {
							for (int j = 0; j < tColumnProperty [o, 0]; j++) {
								tNameOfItems [o, j, k] = tNameOfItems1 [o, j, i];
							}	
							tItemRect [o, k, 0] = tItemRect1 [o, i, 0];
							tItemRect [o, k, 1] = tItemRect1 [o, i, 1];
							iStartSizes [o, k, 0] = iStartSizes1 [o, i, 0];
							k = k + 1;
						}
						for (int j = 0; j < tColumnProperty [o, 0]; j++) {
							tNameOfItems [o, j, k] = tNameOfItems1 [o, j, i];
						}
						tItemRect [o, k, 0] = tItemRect1 [o, i, 0];
						tItemRect [o, k, 1] = tItemRect1 [o, i, 1];
						iStartSizes [o, k, 0] = iStartSizes1 [o, i, 0]; // Указанные размеры рядов (0-высота ряда)

						k = k + 1;
					}
				} else {
					for (int i = 0; i < tItemProperty [o, 0]; i++) {
						for (int j = 0; j < tColumnProperty [o, 0]; j++) {
							tNameOfItems [o, j, i] = tNameOfItems1 [o, j, i];
						}
						tItemRect [o, i, 0] = tItemRect1 [o, i, 0];
						tItemRect [o, i, 1] = tItemRect1 [o, i, 1];
						iStartSizes [o, i, 0] = iStartSizes1 [o, i, 0]; // Указанные размеры рядов (0-высота ряда)
					}
				}
			}
				
			tNumOfItem [ListViewSelected] = tNumOfItem [ListViewSelected] + 1;

			ChangeSizes (ListViewSelected); // Поменять размеры таблицы

			ShowItem2 (); // Показать выделенную колонку или ряд если за пределами прорисовки ************	

			// Сохранить таблицы после изменения
			Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
				tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
		}
		return true;
	}

	public bool DeleteRowLV () { // Удалить ряд ListView	
		if (ListViewSelected > -1) {
			if (tItemProperty [ListViewSelected, 0] > 1) {
				// Сохранить таблицы перед изменением
				Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
					tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"

				// Таблица
				string[,,] tNameOfItems1 = new string[Count_ListView, MaxColumnCount, MaxItemCount];
				//Rect[,,] tColumnRect1 = new Rect[Count_ListView, MaxColumnCount , 3];
				Rect[,,] tItemRect1 = new Rect[Count_ListView, MaxItemCount , 2];
				//float[,,] cStartSizes1 = new float[Count_ListView, MaxColumnCount , 2]; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
				float[,,] iStartSizes1 = new float[Count_ListView, MaxItemCount , 1]; // Указанные размеры рядов (0-высота ряда)

				for (int o = 0; o < Count_ListView; o++) {
					for (int i = 0; i < tItemProperty [o, 0]; i++) {
						for (int j = 0; j < tColumnProperty [o, 0]; j++) {
							tNameOfItems1 [o, j, i] = tNameOfItems [o, j, i];
						}
						tItemRect1 [o, i, 0] = tItemRect [o, i, 0];
						tItemRect1 [o, i, 1] = tItemRect [o, i, 1];
						iStartSizes1 [o, i, 0] = iStartSizes [o, i, 0];
					}
				}

				tItemProperty [ListViewSelected, 0] = tItemProperty [ListViewSelected, 0] - 1;

				int k;
				if (tItemProperty [ListViewSelected, 0] > 0) {
					for (int o = 0; o < Count_ListView; o++) {			
						if (o == ListViewSelected) {
							k = 0;
							for (int i = 0; i < tItemProperty [o, 0]; i++) {
								if (k == tNumOfItem [o]) {
									k = k + 1;
								}
								if (k < tItemProperty [o, 0] + 1) {
									for (int j = 0; j < tColumnProperty [o, 0]; j++) {
										tNameOfItems [o, j, i] = tNameOfItems1 [o, j, k];
									}
									tItemRect [o, i, 0] = tItemRect1 [o, k, 0];
									tItemRect [o, i, 1] = tItemRect1 [o, k, 1];
									iStartSizes [o, i, 0] = iStartSizes1 [o, k, 0];
								}
								k = k + 1;
							}
						} else {
							for (int i = 0; i < tItemProperty [o, 0]; i++) {
								for (int j = 0; j < tColumnProperty [o, 0]; j++) {
									tNameOfItems [o, j, i] = tNameOfItems1 [o, j, i];
								}
								tItemRect [o, i, 0] = tItemRect1 [o, i, 0];
								tItemRect [o, i, 1] = tItemRect1 [o, i, 1];
								iStartSizes [o, i, 0] = iStartSizes1 [o, i, 0];
							}
						}
					}
				}		

				if (tNumOfItem [ListViewSelected] >= tItemProperty [ListViewSelected, 0]) {								
					tNumOfItem [ListViewSelected] = Mathf.FloorToInt (tItemProperty [ListViewSelected, 0] - 1);
				}

				ChangeSizes (ListViewSelected); // Поменять размеры таблицы

				ShowItem2 (); // Показать выделенную колонку или ряд если за пределами прорисовки ************	

				// Сохранить таблицы после изменения
				Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
					tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
			}
		}
		return true;
	}

	public bool AddColumnLV () { // Добавить колонку ListView	
		if (ListViewSelected > -1) {
			// Сохранить таблицы перед изменением
			Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
				tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"

			// Таблица
			string[,] tNameOfColumns1 = new string[Count_ListView, MaxColumnCount];
			string[,,] tNameOfItems1 = new string[Count_ListView, MaxColumnCount, MaxItemCount];
			Rect[,,] tColumnRect1 = new Rect[Count_ListView, MaxColumnCount , 3];
			//Rect[,,] tItemRect1 = new Rect[Count_ListView, MaxItemCount , 2];
			float[,,] cStartSizes1 = new float[Count_ListView, MaxColumnCount , 2]; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
			//float[,,] iStartSizes1 = new float[Count_ListView, MaxItemCount , 1]; // Указанные размеры рядов (0-высота ряда)

			for (int o = 0; o < Count_ListView; o++) {
				for (int i = 0; i < tColumnProperty [o, 0]; i++) {
					tNameOfColumns1 [o, i] = tNameOfColumns [o, i];
					for (int j = 0; j < tItemProperty [o, 0]; j++) {
						tNameOfItems1 [o, i, j] = tNameOfItems [o, i, j];
					}
					tColumnRect1 [o, i, 0] = tColumnRect [o, i, 0];
					tColumnRect1 [o, i, 1] = tColumnRect [o, i, 1];
					tColumnRect1 [o, i, 2] = tColumnRect [o, i, 2];
					cStartSizes1 [o, i, 0] = cStartSizes [o, i, 0];
					cStartSizes1 [o, i, 1] = cStartSizes [o, i, 1];
				}
			}

			tColumnProperty [ListViewSelected, 0] = tColumnProperty [ListViewSelected, 0] + 1;

			if (tColumnProperty [ListViewSelected, 0] > MaxColumnCount) {
				MaxColumnCount = Mathf.FloorToInt (tColumnProperty [ListViewSelected, 0]); // Максимальное количество колонок

				tColumnRect = new Rect[Count_ListView, MaxColumnCount , 3]; // 0-позиция колонки, 1-позиция кнопки X, 2-позиция текста в колонке
				//tItemRect = new Rect[Count_ListView, MaxItemCount , 2]; // 0-позиция ряда, 1-позиция кнопки Y
				cStartSizes = new float[Count_ListView, MaxColumnCount , 2]; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
				//iStartSizes = new float[Count_ListView, MaxItemCount , 1]; // Указанные размеры рядов (0-высота ряда)
				tNameOfColumns = new string[Count_ListView, MaxColumnCount];
				tNameOfItems = new string[Count_ListView, MaxColumnCount, MaxItemCount];
			}

			int k;

			for (int o = 0; o < Count_ListView; o++) {			
				if (o == ListViewSelected) {	
					k = 0;
					for (int i = 0; i < tColumnProperty [o, 0] - 1; i++) {
						if (k == tNumOfColumn [ListViewSelected]) {
							tNameOfColumns [o, k] = tNameOfColumns1 [o, i];
							for (int j = 0; j < tItemProperty [o, 0]; j++) {
								tNameOfItems [o, k, j] = tNameOfItems1 [o, i, j];
							}	
							tColumnRect [o, k, 0] = tColumnRect1 [o, i, 0];
							tColumnRect [o, k, 1] = tColumnRect1 [o, i, 1];
							tColumnRect [o, k, 2] = tColumnRect1 [o, i, 2];
							cStartSizes [o, k, 0] = cStartSizes1 [o, i, 0];
							cStartSizes [o, k, 1] = cStartSizes1 [o, i, 1];
							k = k + 1;
						}
						tNameOfColumns [o, k] = tNameOfColumns1 [o, i];
						for (int j = 0; j < tItemProperty [o, 0]; j++) {
							tNameOfItems [o, k, j] = tNameOfItems1 [o, i, j];
						}
						tColumnRect [o, k, 0] = tColumnRect1 [o, i, 0];
						tColumnRect [o, k, 1] = tColumnRect1 [o, i, 1];
						tColumnRect [o, k, 2] = tColumnRect1 [o, i, 2];
						cStartSizes [o, k, 0] = cStartSizes1 [o, i, 0];
						cStartSizes [o, k, 1] = cStartSizes1 [o, i, 1];
						k = k + 1;
					}
				} else {
					for (int i = 0; i < tColumnProperty [o, 0]; i++) {
						tNameOfColumns [o, i] = tNameOfColumns1 [o, i];
						for (int j = 0; j < tItemProperty [o, 0]; j++) {
							tNameOfItems [o, i, j] = tNameOfItems1 [o, i, j];
						}
						tColumnRect [o, i, 0] = tColumnRect1 [o, i, 0];
						tColumnRect [o, i, 1] = tColumnRect1 [o, i, 1];
						tColumnRect [o, i, 2] = tColumnRect1 [o, i, 2];
						cStartSizes [o, i, 0] = cStartSizes1 [o, i, 0];
						cStartSizes [o, i, 1] = cStartSizes1 [o, i, 1];
					}
				}
			}

			tNumOfColumn [ListViewSelected] = tNumOfColumn [ListViewSelected] + 1;

			ChangeSizes (ListViewSelected); // Поменять размеры таблицы

			ShowItem2 (); // Показать выделенную колонку или ряд если за пределами прорисовки ************	

			// Сохранить таблицы после изменения
			Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
				tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
		}
		return true;
	}

	public bool DeleteColumnLV () { // Удалить колонку ListView	
		if (ListViewSelected > -1) {
			if (tColumnProperty [ListViewSelected, 0] > 1) {
				// Сохранить таблицы перед изменением
				Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
					tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"

				// Таблица
				string[,] tNameOfColumns1 = new string[Count_ListView, MaxColumnCount];
				string[,,] tNameOfItems1 = new string[Count_ListView, MaxColumnCount, MaxItemCount];
				Rect[,,] tColumnRect1 = new Rect[Count_ListView, MaxColumnCount , 3];
				//Rect[,,] tItemRect1 = new Rect[Count_ListView, MaxItemCount , 2];
				float[,,] cStartSizes1 = new float[Count_ListView, MaxColumnCount , 2]; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
				//float[,,] iStartSizes1 = new float[Count_ListView, MaxItemCount , 1]; // Указанные размеры рядов (0-высота ряда)

				for (int o = 0; o < Count_ListView; o++) {
					for (int i = 0; i < tColumnProperty [o, 0]; i++) {
						tNameOfColumns1 [o, i] = tNameOfColumns [o, i];
						for (int j = 0; j < tItemProperty [o, 0]; j++) {
							tNameOfItems1 [o, i, j] = tNameOfItems [o, i, j];
						}
						tColumnRect1 [o, i, 0] = tColumnRect [o, i, 0];
						tColumnRect1 [o, i, 1] = tColumnRect [o, i, 1];
						tColumnRect1 [o, i, 2] = tColumnRect [o, i, 2];
						cStartSizes1 [o, i, 0] = cStartSizes [o, i, 0];
						cStartSizes1 [o, i, 1] = cStartSizes [o, i, 1];
					}
				}

				tColumnProperty [ListViewSelected, 0] = tColumnProperty [ListViewSelected, 0] - 1;

				int k;
				if (tColumnProperty [ListViewSelected, 0] > 0) {
					for (int o = 0; o < Count_ListView; o++) {			
						if (o == ListViewSelected) {
							k = 0;
							for (int i = 0; i < tColumnProperty [o, 0]; i++) {
								if (k == tNumOfItem [o]) {
									k = k + 1;
								}
								if (k < tColumnProperty [o, 0] + 1) {
									tNameOfColumns [o, i] = tNameOfColumns1 [o, k];
									for (int j = 0; j < tItemProperty [o, 0]; j++) {
										tNameOfItems [o, i, j] = tNameOfItems1 [o, k, j];
									}
									tColumnRect [o, i, 0] = tColumnRect1 [o, k, 0];
									tColumnRect [o, i, 1] = tColumnRect1 [o, k, 1];
									tColumnRect [o, i, 2] = tColumnRect1 [o, k, 2];
									cStartSizes [o, i, 0] = cStartSizes1 [o, k, 0];
									cStartSizes [o, i, 1] = cStartSizes1 [o, k, 1];
								}
								k = k + 1;
							}
						} else {
							for (int i = 0; i < tColumnProperty [o, 0]; i++) {
								tNameOfColumns [o, i] = tNameOfColumns1 [o, i];
								for (int j = 0; j < tItemProperty [o, 0]; j++) {
									tNameOfItems [o, i, j] = tNameOfItems1 [o, i, j];
								}
								tColumnRect [o, i, 0] = tColumnRect1 [o, i, 0];
								tColumnRect [o, i, 1] = tColumnRect1 [o, i, 1];
								tColumnRect [o, i, 2] = tColumnRect1 [o, i, 2];
								cStartSizes [o, i, 0] = cStartSizes1 [o, i, 0];
								cStartSizes [o, i, 1] = cStartSizes1 [o, i, 1];
							}
						}
					}
				}		

				if (tNumOfColumn [ListViewSelected] >= tColumnProperty [ListViewSelected, 0]) {								
					tNumOfColumn [ListViewSelected] = Mathf.FloorToInt (tColumnProperty [ListViewSelected, 0] - 1);
				}

				ChangeSizes (ListViewSelected); // Поменять размеры таблицы

				ShowItem2 (); // Показать выделенную колонку или ряд если за пределами прорисовки ************	

				// Сохранить таблицы после изменения
				Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
					tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
			}
		}
		return true;
	}

	public bool CreateOptions () { // Установить свойства компонента ListView	
		Show_Hide_count = 15;
		Show_Hide = new bool[Show_Hide_count];
		Show_Hide [0] = true; // true - Показывать подсказку для ячеек
		Show_Hide [1] = true; // true - Выделять ряд с выбранной ячейкой
		Show_Hide [2] = true; // true - Выделять колонку с выбранной ячейкой
		Show_Hide [3] = true; // true - Выделять колонку с названием
		Show_Hide [4] = true; // true - Возможность редактировать ячейку
		Show_Hide [5] = true; // true - Сохранять редактированный текст ячейки
		Show_Hide [6] = true; // true - Увеличивать редактируемую ячейку
		Show_Hide [7] = false; // true - Увеличивать выделенную ячейку
		Show_Hide [8] = true; // true - Возможность редактировать колонку
		Show_Hide [9] = true; // true - Сохранять редактированный текст колонки
		Show_Hide [10] = true; // true - Показывать подсказку для колонок
		Show_Hide [11] = true; // true - Выбирать ячейку нажатием на колонку
		Show_Hide [12] = true; // true - Показывать подсказку после перемещения клавишами
		Show_Hide [13] = true; // true - Показывать колонку (показывает/убирает в момент создания таблицы)
		Show_Hide [14] = true; // true - Показывать контекстное меню

		Show_Hide_name = new string[Show_Hide_count];
		Show_Hide_name [0] = "0. Показывать подсказку для ячеек";
		Show_Hide_name [1] = "1. Выделять ряд с выбранной ячейкой";
		Show_Hide_name [2] = "2. Выделять колонку с выбранной ячейкой";
		Show_Hide_name [3] = "3. Выделять колонку с названием";
		Show_Hide_name [4] = "4. Возможность редактировать ячейку";
		Show_Hide_name [5] = "5. Сохранять редактированный текст ячейки";
		Show_Hide_name [6] = "6. Увеличивать редактируемую ячейку";
		Show_Hide_name [7] = "7. Увеличивать выделенную ячейку";
		Show_Hide_name [8] = "8. Возможность редактировать колонку";
		Show_Hide_name [9] = "9. Сохранять редактированный текст колонки";
		Show_Hide_name [10] = "10. Показывать подсказку для колонок";
		Show_Hide_name [11] = "11. Выбирать ячейку нажатием на колонку";
		Show_Hide_name [12] = "12. Показывать подсказку после перемещения клавишами";
		Show_Hide_name [13] = "13. Показывать колонку ('Load' перестроить таблицы)";
		Show_Hide_name [14] = "14. Показывать контекстное меню";


		Count_ListView = 3; // Кол-во таблиц ListView

		MaxColumnCount = 10; // Максимальное количество колонок
		MaxItemCount = 10; // Максимальное количество рядов
		//////////////////////////////////////////////////

		timeKeyPressed = new float[3]; // Время нажатий клавиш
		timeKeyPressed[0] = 0; // Курсором выделен "ListView"
		timeKeyPressed[1] = 0; // Клавиша "Enter"
		timeKeyPressed[2] = 0; // Клавиша "Tab"

		ListViewColumnHint = new int[2]; // Номер колонки для отображения подсказки
		ListViewColumnHint[0] = -1; // Номер ListView
		ListViewColumnHint[1] = -1; // Номер колонки для отображения подсказки

		ListViewItemHint = new int[3]; // Номер ячейки для отображения подсказки
		ListViewItemHint[0] = -1; // Номер ListView
		ListViewItemHint[1] = -1; // Номер колонки для отображения подсказки
		ListViewItemHint[2] = -1; // Номер ряда для отображения подсказки

		FirstCreateGUI = false; // false-если первый цикл GUI
		ListViewSelected = -1; // ListView не выделен
		timeShowHint = 0;

		selStrings = new string[] {"Cut", "Copy", "Paste", "Replace", "Undo", "Redo"};
		tNumOfColumn = new int[Count_ListView];
		tNumOfItem = new int[Count_ListView];
		MouseDoubleClick = new int[Count_ListView];
		MouseLeftClick = new int[Count_ListView];
		CMchanged = new int[Count_ListView];
		CMbutton = new int[Count_ListView];
		LPartVisibleColumn = new int[Count_ListView];
		timeLeft = new float[Count_ListView];
		timeMouseClick = new float[Count_ListView];
		EditInField = new bool[Count_ListView]; // true-если редактируется текст в ячейке
		EditInColumn = new bool[Count_ListView]; // true-если редактируется текст в колонке
		ChangingText = new string[Count_ListView];
		tColumnProperty = new float[Count_ListView, 2]; // 0-кол-во колонок, 1-отступ по Y между колонкой и кнопкой
		tItemProperty = new float[Count_ListView, 3]; // 0-кол-во рядов, 1-отступ по X между рядами, 2-отступ по Y между кнопками
		HV_Scroll1 = new float[Count_ListView, 2]; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара)
		cStartSizes = new float[Count_ListView, MaxColumnCount, 2]; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		iStartSizes = new float[Count_ListView, MaxItemCount, 1]; // Указанные размеры рядов (0-высота ряда)
		tColumnRect = new Rect[Count_ListView, MaxColumnCount , 3]; // 0-позиция колонки, 1-позиция кнопки X, 2-позиция текста в колонке
		tItemRect = new Rect[Count_ListView, MaxItemCount , 2]; // 0-позиция ряда, 1-позиция кнопки Y
		tNameOfColumns = new string[Count_ListView, MaxColumnCount]; // Названия колонок
		tNameOfItems = new string[Count_ListView, MaxColumnCount , MaxItemCount]; // Названия кнопок
		Active_ListView = new Rect[Count_ListView]; // Позиция, размеры квадрата с активным "ListView"
		Rect_Scroll = new Rect[Count_ListView, 6];		
		GuiArrStyle = new GUIStyle[Count_ListView, 14];
		scrollPosition = new Vector2[Count_ListView];
		scrollPosition_check = new Vector2[Count_ListView];
		clickPosition = new Vector2[Count_ListView];
		TableSize_wh = new Vector2[Count_ListView]; // Размеры таблицы внутри скроллбара
		ChangeVariables = new int[Count_ListView, 4];

		////////////////////////////////////////////////////////////////////////
		Copy_MaximumOfChanges = 100; // Количество сохраняемых действий
		Copy_MaximumOfColumns = new int [Copy_MaximumOfChanges];
		Copy_MaximumOfItems = new int [Copy_MaximumOfChanges];
		Copy_MaximumOfColumns [0] = MaxColumnCount;
		Copy_MaximumOfItems [0] = MaxItemCount;
		Copy_Count_ListView = new int [Copy_MaximumOfChanges];
		Copy_ListViewSelected = new int [Copy_MaximumOfChanges];
		Copy_tColumnProperty = new float [Copy_MaximumOfChanges,2];
		Copy_tNumOfColumn = new int [Copy_MaximumOfChanges];
		Copy_tItemProperty = new float [Copy_MaximumOfChanges,3];
		Copy_tNumOfItem = new int [Copy_MaximumOfChanges];
		Copy_tNameOfColumns = new string [Copy_MaximumOfChanges,Copy_MaximumOfColumns [0]];
		Copy_tNameOfItems = new string [Copy_MaximumOfChanges,Copy_MaximumOfColumns [0], Copy_MaximumOfItems [0]];
		Copy_cStartSizes = new float [Copy_MaximumOfChanges,Copy_MaximumOfColumns [0],2]; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		Copy_iStartSizes = new float [Copy_MaximumOfChanges,Copy_MaximumOfItems [0],1]; // Указанные размеры рядов (0-высота ряда)
		Copy_tColumnRect = new Rect [Copy_MaximumOfChanges,Copy_MaximumOfColumns [0],3]; // 0-позиция колонки, 1-позиция кнопки X, 2-позиция текста в колонке
		Copy_tItemRect =new Rect [Copy_MaximumOfChanges,Copy_MaximumOfItems [0],2]; // 0-позиция ряда, 1-позиция кнопки Y
		////////////////////////////////////////////////////////////////////////

		int numofthis1;
		float width1, height1;
		MainRect_float = new float[Count_ListView,4]; // 0-X, 1-Y, 2-Width, 3-Height скролла (границ) компонента ListView

		// Указать свойства ListView 0 //////////////////////////////////////////////
		Number_ListView = 0;

		MainRect_float [Number_ListView, 0] = 10; // позиция компонента ListView по X
		MainRect_float [Number_ListView, 1] = 60; // позиция компонента ListView по Y
		MainRect_float [Number_ListView, 2] = 500; // Ширина скролла (границ) компонента ListView
		MainRect_float [Number_ListView, 3] = 300; // Высота скролла (границ) компонента ListView

		tColumnProperty[Number_ListView, 0] = 10; // 0-кол-во колонок
		tItemProperty[Number_ListView, 0] = 10; // 0-кол-во рядов
		tNumOfColumn [Number_ListView] = 0; // Номер выделенной колонки
		tNumOfItem [Number_ListView] = 0; // Номер выеленного ряда
		tColumnProperty[Number_ListView, 1] = 5; // 1-отступ по Y между колонкой и кнопкой			
		tItemProperty[Number_ListView, 1] = 5; // 1-отступ по X между рядами
		tItemProperty[Number_ListView, 2] = 2.5f; // 2-отступ по Y между кнопками
			

		height1 = 50; // высота колонок

		// Колонки ////////
		numofthis1 = 0; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 1; // номер колонки
		width1 = 120; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 2; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")

		numofthis1 = 3; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 4; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 5; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 6; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 7; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 8; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 9; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")

		// Ряды ////////
		numofthis1 = 0; // номер ряда
		height1 = 50; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 1; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 2; // номер ряда
		height1 = 30; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 3; // номер ряда
		height1 = 50; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 4; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)

		numofthis1 = 5; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 6; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 7; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 8; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 9; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		/////////////////////////////////////////////////////////////////////


		// Указать свойства ListView 1 //////////////////////////////////////////////
		Number_ListView = 1;

		MainRect_float [Number_ListView, 0] = 10; // позиция компонента ListView по X
		MainRect_float [Number_ListView, 1] = 390; // позиция компонента ListView по Y
		MainRect_float [Number_ListView, 2] = 300; // Ширина скролла (границ) компонента ListView
		MainRect_float [Number_ListView, 3] = 200; // Высота скролла (границ) компонента ListView

		tColumnProperty[Number_ListView, 0] = 5; // 0-кол-во колонок
		tItemProperty[Number_ListView, 0] = 8; // 0-кол-во рядов
		tNumOfColumn [Number_ListView] = 0; // Номер выделенной колонки
		tNumOfItem [Number_ListView] = 0; // Номер выеленного ряда
		tColumnProperty[Number_ListView, 1] = 5; // 1-отступ по Y между колонкой и кнопкой			
		tItemProperty[Number_ListView, 1] = 5; // 1-отступ по X между рядами
		tItemProperty[Number_ListView, 2] = 2.5f; // 2-отступ по Y между кнопками

		height1 = 50; // высота колонок

		// Колонки ////////
		numofthis1 = 0; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 1; // номер колонки
		width1 = 120; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 2; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")

		numofthis1 = 3; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 4; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 5; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 6; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 7; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 8; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 9; // номер колонки
		width1 = 70; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")

		// Ряды ////////
		numofthis1 = 0; // номер ряда
		height1 = 50; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 1; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 2; // номер ряда
		height1 = 30; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 3; // номер ряда
		height1 = 50; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 4; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)

		numofthis1 = 5; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 6; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 7; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 8; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 9; // номер ряда
		height1 = 80; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		/////////////////////////////////////////////////////////////////////


		// Указать свойства ListView 2 //////////////////////////////////////////////
		Number_ListView = 2;

		MainRect_float [Number_ListView, 0] = 330; // позиция компонента ListView по X
		MainRect_float [Number_ListView, 1] = 390; // позиция компонента ListView по Y
		MainRect_float [Number_ListView, 2] = 180; // Ширина скролла (границ) компонента ListView
		MainRect_float [Number_ListView, 3] = 200; // Высота скролла (границ) компонента ListView

		tColumnProperty[Number_ListView, 0] = 10; // 0-кол-во колонок
		tItemProperty[Number_ListView, 0] = 5; // 0-кол-во рядов
		tNumOfColumn [Number_ListView] = 0; // Номер выделенной колонки
		tNumOfItem [Number_ListView] = 0; // Номер выеленного ряда
		tColumnProperty[Number_ListView, 1] = 0; // 1-отступ по Y между колонкой и кнопкой			
		tItemProperty[Number_ListView, 1] = 5; // 1-отступ по X между рядами
		tItemProperty[Number_ListView, 2] = 2.5f; // 2-отступ по Y между кнопками

		height1 = 0; // высота колонок

		// Колонки ////////
		numofthis1 = 0; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 1; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 2; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")

		numofthis1 = 3; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 4; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 5; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 6; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 7; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 8; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		numofthis1 = 9; // номер колонки
		width1 = 40; // ширина колонки
		cStartSizes[Number_ListView, numofthis1,0] = width1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
		cStartSizes[Number_ListView, numofthis1,1] = height1; // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")

		// Ряды ////////
		numofthis1 = 0; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 1; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 2; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 3; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 4; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)

		numofthis1 = 5; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 6; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 7; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 8; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)
		numofthis1 = 9; // номер ряда
		height1 = 40; // высота ряда
		iStartSizes[Number_ListView, numofthis1,0] = height1; // Указанные размеры рядов (0-высота ряда)

		for (Number_ListView = 0; Number_ListView <= Count_ListView - 1; Number_ListView++) {
			Rect_Scroll [Number_ListView, 1] = new Rect (MainRect_float [Number_ListView, 0],
				MainRect_float [Number_ListView, 1], MainRect_float [Number_ListView, 2], 
				MainRect_float [Number_ListView, 3]); // Ширина и высота компонента ListView с ползунками			

			ChangeSizes (Number_ListView); // Поменять размеры таблицы
		}
			

		LoadTables = new string[2]; // Номер загрузки
		SaveTables = new string[2]; // Номер сохранения
		LoadTables [0] = "0";
		SaveTables [0] = "0";
		LoadTables [1] = "0";
		SaveTables [1] = "0";

		rect_SaveLoad = new Rect[4];
		rect_SaveLoad [0] = new Rect (Rect_Scroll [0, 1].xMax+40, Rect_Scroll [0, 1].y, 90, 40); // Координаты кнопки "Сохранить"
		rect_SaveLoad [1] = new Rect (rect_SaveLoad [0].x, Rect_Scroll [0, 1].y + 50, 90, 40); // Координаты кнопки "Загрузить"
		rect_SaveLoad [2] = new Rect (rect_SaveLoad [0].xMax+10, 
			rect_SaveLoad [0].y + (rect_SaveLoad [0].height-30)/2f, 25, 30); // Координаты номера сохранить
		rect_SaveLoad [3] = new Rect (rect_SaveLoad [1].xMax+10, 
			rect_SaveLoad [1].y + (rect_SaveLoad [1].height-30)/2f, 25, 30); // Координаты номера загрузить

		rect_AddDelRowColumn = new Rect[6];
		rect_AddDelRowColumn [0] = new Rect (rect_SaveLoad [1].x,rect_SaveLoad [1].yMax + 10, 40, 40); // Координаты кнопки "Удалить колонку"
		rect_AddDelRowColumn [1] = new Rect (rect_AddDelRowColumn [0].xMax + 10, rect_AddDelRowColumn [0].y, 40, 40); // Координаты кнопки "Добавить колонку"
		rect_AddDelRowColumn [2] = new Rect (rect_AddDelRowColumn [0].x, rect_AddDelRowColumn [0].yMax + 10, 40, 40); // Координаты кнопки "Удалить ряд"
		rect_AddDelRowColumn [3] = new Rect (rect_AddDelRowColumn [0].xMax + 10, rect_AddDelRowColumn [2].y, 40, 40); // Координаты кнопки "Добавить ряд"

		rect_AddDelRowColumn [4] = new Rect (rect_AddDelRowColumn [2].x, rect_AddDelRowColumn [2].yMax+10, 150, 100); // Координаты кнопки "Скролл для чекбоксов"
		rect_AddDelRowColumn [5] = new Rect (0, 0, 380, Show_Hide_count*18+5); // Координаты кнопки "Скролл для чекбоксов"

		return true;
	}

	public bool ChangeSizes (int Number_ListView_1) { // Поменять размеры таблицы	
		scrollPosition [Number_ListView_1] = new Vector2 (0, 0);
		scrollPosition_check [Number_ListView_1] = new Vector2 (-1, -1);

		TableSize_wh [Number_ListView_1] = new Vector2 (0, 0); // Размеры таблицы внутри скроллбара
		float height1 = 0;
		float xpos1 = 1; // позиция ряда по X
		float ypos1 = 0; // позиция ряда по Y
		for (int i = 0; i <= tColumnProperty [Number_ListView_1, 0] - 1; i++) {					
			if (i > 0)
				xpos1 = xpos1 + cStartSizes [Number_ListView_1, i-1, 0] + 1;			

			if (Show_Hide [13] == false) { // Если не нужно прорисовывать колонку
				ypos1 = 0;
			} else {
				ypos1 = cStartSizes [Number_ListView_1, i, 1] + tColumnProperty [Number_ListView_1, 1];
			}
			height1 = ypos1;

			/*if (FirstCreateGUI == false) {
				tColumnRect [Number_ListView_1, i, 0] = new Rect (xpos1, 0,
					tColumnRect [Number_ListView_1, i, 0].width, ypos1); // позиция колонки			
				tColumnRect [Number_ListView_1, i, 1] = new Rect (tColumnRect [Number_ListView_1, i, 0].x + tItemProperty [Number_ListView_1, 1], 0,
					tColumnRect [Number_ListView_1, i, 0].width - tItemProperty [Number_ListView_1, 1] * 2f, 0); // позиция кнопки X			
				tColumnRect [Number_ListView_1, i, 2] = new Rect (xpos1 + tItemProperty [Number_ListView_1, 1], 0,
					tColumnRect [Number_ListView_1, i, 0].width - tItemProperty [Number_ListView_1, 1] * 2, 
					ypos1); // позиция текста в колонке				
			}*/

			tColumnRect [Number_ListView_1, i, 0] = new Rect (xpos1, 0,
				cStartSizes [Number_ListView_1, i, 0], ypos1); // позиция колонки			
			tColumnRect [Number_ListView_1, i, 1] = new Rect (tColumnRect [Number_ListView_1, i, 0].x + tItemProperty [Number_ListView_1, 1], 0,
				cStartSizes [Number_ListView_1, i, 0] - tItemProperty [Number_ListView_1, 1] * 2f, 0); // позиция кнопки X			
			tColumnRect [Number_ListView_1, i, 2] = new Rect (xpos1 + tItemProperty [Number_ListView_1, 1], 0,
				cStartSizes [Number_ListView_1, i, 0] - tItemProperty [Number_ListView_1, 1] * 2, 
				ypos1); // позиция текста в колонке	


			for (int j = 0; j <= tItemProperty [Number_ListView_1, 0] - 1; j++) {
				if (j > 0)
					ypos1 = ypos1 + tItemRect [Number_ListView_1, j - 1, 0].height;

					tItemRect [Number_ListView_1, j, 0] = new Rect (xpos1, ypos1, 
						tColumnRect [Number_ListView_1, i, 0].width, // ширина ряда
			    		iStartSizes [Number_ListView_1, j, 0]); // высота ряда

					tItemRect [Number_ListView_1, j, 1] = new Rect (tItemRect [Number_ListView_1, j, 0].x + tItemProperty [Number_ListView_1, 1], // позиция кнопки по X
						tItemRect [Number_ListView_1, j, 0].y + tItemProperty [Number_ListView_1, 2], // позиция кнопки по Y
						tColumnRect [Number_ListView_1, i, 1].width, // ширина кнопки
	    				iStartSizes [Number_ListView_1, j, 0] - tItemProperty [Number_ListView_1, 2] * 2f); // высота кнопки

				height1 = height1 + iStartSizes [Number_ListView_1, j, 0];

				if (FirstCreateGUI == false) {
					tNameOfItems [Number_ListView_1, i, j] = "Item " + j.ToString ();	
				}
			}
			if (height1 > TableSize_wh [Number_ListView_1].y)
				TableSize_wh [Number_ListView_1] = new Vector2 (TableSize_wh [Number_ListView_1].x, height1);
			TableSize_wh [Number_ListView_1] = new Vector2 (TableSize_wh [Number_ListView_1].x +
			tColumnRect [Number_ListView_1, i, 0].width + 1f, 
				TableSize_wh [Number_ListView_1].y);

			if (FirstCreateGUI == false) {
				tNameOfColumns [Number_ListView_1, i] = "Column " + i.ToString ();
			}

		}
		TableSize_wh [Number_ListView_1] = new Vector2 (TableSize_wh [Number_ListView_1].x + 1f,
			TableSize_wh [Number_ListView_1].y + tItemProperty [Number_ListView_1, 2]);
					
		Rect_Scroll [Number_ListView_1, 3] = new Rect (0, 0, TableSize_wh [Number_ListView_1].x, TableSize_wh [Number_ListView_1].y);	// Общая ширина, высота со всеми кнопками и колонками

		CheckScrolls (Number_ListView_1); // Проверить есть ли скроллбары

		Active_ListView [Number_ListView_1] = 
				new Rect (Rect_Scroll [Number_ListView_1, 1].xMax - 15,
			Rect_Scroll [Number_ListView_1, 1].yMax - 15, 15, 15); // Позиция, размеры квадрата с активным "ListView"				
		return true;	
	}

	public bool CheckScrolls (int Number_ListView_1) { // Проверить есть ли скроллбары	
		if (Rect_Scroll[Number_ListView_1, 3].width>Rect_Scroll[Number_ListView_1, 1].width) // Если ширина текст. комп. больше ширины комп. со скроллбаром, нужен горизонтальный скроллбар
			HV_Scroll1 [Number_ListView_1, 0] = 16; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара)
		else HV_Scroll1 [Number_ListView_1, 0] = 0; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара) 
		if (Rect_Scroll[Number_ListView_1, 3].height>Rect_Scroll[Number_ListView_1, 1].height) // Если высота текст. комп. больше высоты комп. со скроллбаром, нужен вертикальный скроллбар
			HV_Scroll1 [Number_ListView_1, 1] = 16; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара)
		else HV_Scroll1 [Number_ListView_1, 1] = 0; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара)
		if (Rect_Scroll[Number_ListView_1, 3].width>(Rect_Scroll[Number_ListView_1, 1].width-HV_Scroll1 [Number_ListView_1, 1])) // Если ширина текст. комп. больше ширины комп. со скроллбаром, нужен горизонтальный скроллбар
			HV_Scroll1 [Number_ListView_1, 0] = 16; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара)
		else HV_Scroll1 [Number_ListView_1, 0] = 0; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара) 
		if (Rect_Scroll[Number_ListView_1, 3].height>(Rect_Scroll[Number_ListView_1, 1].height-HV_Scroll1 [Number_ListView_1, 0])) // Если высота текст. комп. больше высоты комп. со скроллбаром, нужен вертикальный скроллбар
			HV_Scroll1 [Number_ListView_1, 1] = 16; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара)
		else HV_Scroll1 [Number_ListView_1, 1] = 0; // 0-горизонтальный, 1-вертикальный скроллбар, (16-если есть, 0-если нету скроллбара)
		Rect_Scroll[Number_ListView_1, 2] = new Rect (Rect_Scroll[Number_ListView_1, 1].x, Rect_Scroll[Number_ListView_1, 1].y+tColumnRect[Number_ListView_1, 0,0].height, 
			Rect_Scroll[Number_ListView_1, 1].width-HV_Scroll1 [Number_ListView_1, 1], Rect_Scroll[Number_ListView_1, 1].height-HV_Scroll1 [Number_ListView_1, 0]-tColumnRect[Number_ListView_1, 0,0].height); // Ширина и высота компонента ListView без ползунков

		if (Rect_Scroll[Number_ListView_1, 2].width>MainRect_float [Number_ListView_1, 2]) { // Если ширина вычисленной таблицы меньше указанной
			Rect_Scroll[Number_ListView_1, 1] = new Rect (Rect_Scroll[Number_ListView_1, 1].x,Rect_Scroll[Number_ListView_1, 1].y,
				Rect_Scroll[Number_ListView_1, 3].width+HV_Scroll1 [Number_ListView_1, 1],Rect_Scroll[Number_ListView_1, 1].height); // Ширина и высота компонента ListView с ползунками		
			Rect_Scroll[Number_ListView_1, 2] = new Rect (Rect_Scroll[Number_ListView_1, 2].x,Rect_Scroll[Number_ListView_1, 2].y,
				Rect_Scroll[Number_ListView_1, 3].width,Rect_Scroll[Number_ListView_1, 2].height); // Ширина и высота компонента ListView с ползунками	
		}
		if (Rect_Scroll[Number_ListView_1, 2].height+tColumnRect[Number_ListView_1, 0,0].height>MainRect_float [Number_ListView_1, 3]) { // Если высота вычисленной таблицы меньше указанной
			Rect_Scroll[Number_ListView_1, 1] = new Rect (Rect_Scroll[Number_ListView_1, 1].x,Rect_Scroll[Number_ListView_1, 1].y,
				Rect_Scroll[Number_ListView_1, 1].width,Rect_Scroll[Number_ListView_1, 3].height+HV_Scroll1 [Number_ListView_1, 0]); // Ширина и высота компонента ListView с ползунками		
			Rect_Scroll[Number_ListView_1, 2] = new Rect (Rect_Scroll[Number_ListView_1, 2].x,Rect_Scroll[Number_ListView_1, 2].y,
				Rect_Scroll[Number_ListView_1, 2].width,Rect_Scroll[Number_ListView_1, 3].height-tColumnRect[Number_ListView_1, 0,0].height); // Ширина и высота компонента ListView с ползунками	
		}
		Rect_Scroll [Number_ListView_1, 0] = new Rect (
			Rect_Scroll[Number_ListView_1, 1].x, Rect_Scroll[Number_ListView_1, 1].y, 
			Rect_Scroll[Number_ListView_1, 2].width, tColumnRect[Number_ListView_1,0,0].height); // Позиция, размеры колонок
		//print ("0: "+Rect_Scroll[Number_ListView_1, 0]+"\n"+Rect_Scroll[Number_ListView_1, 1]+"\n"+Rect_Scroll[Number_ListView_1, 2]+"\n"+Rect_Scroll[Number_ListView_1, 3]);	
		return true;
	}

	public bool MakeStyle () { // Установить стили компонентов	
		if (FirstCreateGUI == false) 
		{								
			// Скролл чекбоксов
			Show_Hide_style = new GUIStyle[3];
			Show_Hide_style [0] = new GUIStyle ("Label");
			Show_Hide_style [0].font = TextFontStyle; // Для отображения кириллицы в WebGL
			Show_Hide_style [0].normal.background = MakeTex (50, 50, new Color (0, 0, 0, 1));
			//Show_Hide_style [0].fontSize = 32;
			Show_Hide_style [0].normal.textColor = Color.white;

			// Чекбоксы
			Show_Hide_style [1] = new GUIStyle ("toggle");
			Show_Hide_style [1].font = TextFontStyle; // Для отображения кириллицы в WebGL
			//Show_Hide_style [1].normal.background = MakeTex (50, 50, new Color (0, 0, 0, 0));
			//Show_Hide_style [1].fontSize = 32;
			Show_Hide_style [1].onNormal.textColor = Color.white; // Если включен
			Show_Hide_style [1].normal.textColor = Color.white; // Если выключен

			// Подсказка для чекбоксов
			Show_Hide_style [2] = new GUIStyle ("Label");
			Show_Hide_style [2].font = TextFontStyle; // Для отображения кириллицы в WebGL
			Show_Hide_style [2].normal.background = MakeTex (50, 50, new Color (0, 0, 0, 0));
			//Show_Hide_style [2].fontSize = 32;
			Show_Hide_style [2].normal.textColor = Color.black;

			// Подсказка для колонок
			GuiHintColumnStyle = new GUIStyle ("Label");
			GuiHintColumnStyle.font = TextFontStyle; // Для отображения кириллицы в WebGL
			GuiHintColumnStyle.normal.background = MakeTex (50, 50, new Color (0.8f, 0.8f, 0.8f, 1));
			GuiHintColumnStyle.wordWrap = true;
			//GuiHintColumnStyle.fontSize = 32;
			GuiHintColumnStyle.normal.textColor = Color.black;

			// Подсказка для ячеек
			GuiHintItemStyle = new GUIStyle ("Label");
			GuiHintItemStyle.font = TextFontStyle; // Для отображения кириллицы в WebGL
			GuiHintItemStyle.normal.background = MakeTex (50, 50, new Color (0.8f, 0.8f, 0.8f, 1));
			GuiHintItemStyle.wordWrap = true;
			//GuiHintItemStyle.fontSize = 32;
			GuiHintItemStyle.normal.textColor = Color.black;

			// Фон контекстного меню
			CMStyle = new GUIStyle ("Label");
			CMStyle.font = TextFontStyle; // Для отображения кириллицы в WebGL
			CMStyle.normal.background = MakeTex (50, 50, new Color (0.8f, 0.8f, 0.8f, 1));
			CMStyle.wordWrap = true;
			//CMStyle.fontSize = 32;
			CMStyle.normal.textColor = Color.black;

			// Кнопки контекстного меню
			CMbuttonStyle = new GUIStyle ("Button");
			CMbuttonStyle.font = TextFontStyle; // Для отображения кириллицы в WebGL
			CMbuttonStyle.normal.background = MakeTex (50, 50, new Color (0.8f, 0.8f, 0.8f, 1));
			CMbuttonStyle.wordWrap = true;
			//CMbuttonStyle.fontSize = 32;
			CMbuttonStyle.normal.textColor = Color.black;

			for (int Number_ListView = 0; Number_ListView <= Count_ListView - 1; Number_ListView++) {
				GuiArrStyle [Number_ListView, 0] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 1] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 2] = new GUIStyle ("textField");
				GuiArrStyle [Number_ListView, 3] = new GUIStyle ("Button");
				GuiArrStyle [Number_ListView, 4] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 5] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 6] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 7] = new GUIStyle ("Button");
				GuiArrStyle [Number_ListView, 8] = new GUIStyle ("Button");
				GuiArrStyle [Number_ListView, 9] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 10] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 11] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 12] = new GUIStyle ("Label");
				GuiArrStyle [Number_ListView, 13] = new GUIStyle ("Label");

				// Для отображения кириллицы в WebGL //////////////////////////
				GuiArrStyle [Number_ListView, 0].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 1].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 2].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 3].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 4].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 5].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 6].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 7].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 8].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 9].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 10].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 11].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 12].font = TextFontStyle;
				GuiArrStyle [Number_ListView, 13].font = TextFontStyle;
				///////////////////////////////////////////////////////////////

				// Фон для исключения нажатий курсором на объекты за GUI элементами
				GuiArrStyle [Number_ListView, 0].normal.background = MakeTex (50, 50, new Color (0, 0, 0, 0));
				//GuiArrStyle[Number_ListView, 0].fontSize = 32;
				GuiArrStyle [Number_ListView, 0].normal.textColor = Color.white;

				// Фон, полосы между колонками
				GuiArrStyle [Number_ListView, 1].normal.background = MakeTex (50, 50, new Color (1, 1, 1, 1));
				//GuiArrStyle[Number_ListView, 1].fontSize = 32;
				GuiArrStyle [Number_ListView, 1].normal.textColor = Color.black;

				// Фон, полосы между ячейками
				GuiArrStyle [Number_ListView, 13].normal.background = MakeTex (50, 50, new Color (1, 1, 1, 1));
				//GuiArrStyle[Number_ListView, 13].fontSize = 32;
				GuiArrStyle [Number_ListView, 13].normal.textColor = Color.black;

				// Цвет ячеек
				GuiArrStyle [Number_ListView, 3].normal.background = MakeTex (50, 50, new Color (0.8f, 0, 0, 1));
				//GuiArrStyle[Number_ListView, 3].fontSize = 32;
				GuiArrStyle [Number_ListView, 3].wordWrap = true;
				GuiArrStyle [Number_ListView, 3].alignment = TextAnchor.UpperLeft; // Поменять выравнивание текста
				GuiArrStyle [Number_ListView, 3].normal.textColor = Color.white;

				// Выделенная ячейка
				GuiArrStyle [Number_ListView, 6].normal.background = MakeTex (50, 50, new Color (1, 1, 1, 1));
				//GuiArrStyle[Number_ListView, 6].fontSize = 32;
				GuiArrStyle [Number_ListView, 6].wordWrap = true;
				GuiArrStyle [Number_ListView, 6].normal.textColor = Color.black;

				// Редактируемая ячейка
				GuiArrStyle [Number_ListView, 2].normal.background = MakeTex (50, 50, new Color (0, 0, 0, 1));
				//GuiArrStyle[Number_ListView, 2].fontSize = 32;
				GuiArrStyle [Number_ListView, 2].wordWrap = true;
				GuiArrStyle [Number_ListView, 2].normal.textColor = Color.white;

				// Цвет выделенного ряда
				GuiArrStyle [Number_ListView, 7].normal.background = MakeTex (50, 50, new Color (0, 1, 0, 1));
				//GuiArrStyle[Number_ListView, 7].fontSize = 32;
				GuiArrStyle [Number_ListView, 7].wordWrap = true;
				GuiArrStyle [Number_ListView, 7].alignment = TextAnchor.UpperLeft; // Поменять выравнивание текста
				GuiArrStyle [Number_ListView, 7].normal.textColor = Color.black;

				// Цвет колонок с названиями
				GuiArrStyle [Number_ListView, 4].normal.background = MakeTex (50, tColumnRect [Number_ListView, 0, 0].height, new Color (0, 0, 1, 1));
				GuiArrStyle [Number_ListView, 4].normal.background = MakeTexDraw (GuiArrStyle [Number_ListView, 4].normal.background,
					50, tColumnRect [Number_ListView, 0, 0].height
					, new Rect (0, tColumnRect [Number_ListView, 0, 0].height - tColumnProperty [Number_ListView, 1],
						50, tColumnProperty [Number_ListView, 1])
					, new Color (0, 0, 0, 1)); // Зарисовать прямоугольник на текстуре цветом
				//GuiArrStyle[Number_ListView, 4].fontSize = 32;
				GuiArrStyle [Number_ListView, 4].normal.textColor = Color.white;

				// Цвет выделенной колонки
				GuiArrStyle [Number_ListView, 8].normal.background = MakeTex (50, 50, new Color (1, 1, 0, 1));
				//GuiArrStyle[Number_ListView, 8].fontSize = 32;
				GuiArrStyle [Number_ListView, 8].wordWrap = true;
				GuiArrStyle [Number_ListView, 8].alignment = TextAnchor.UpperLeft; // Поменять выравнивание текста
				GuiArrStyle [Number_ListView, 8].normal.textColor = Color.black;

				// Цвет выделенной колонки с названием
				GuiArrStyle [Number_ListView, 9].normal.background = MakeTex (50, 50, new Color (0, 1, 1, 1));
				GuiArrStyle [Number_ListView, 9].normal.background = MakeTexDraw (GuiArrStyle [Number_ListView, 9].normal.background,
					50, tColumnRect [Number_ListView, 0, 0].height
					, new Rect (0, tColumnRect [Number_ListView, 0, 0].height - tColumnProperty [Number_ListView, 1],
						50, tColumnProperty [Number_ListView, 1])
					, new Color (0, 0, 0, 1)); // Зарисовать прямоугольник на текстуре цветом
				//GuiArrStyle[Number_ListView, 9].fontSize = 32;
				GuiArrStyle [Number_ListView, 9].wordWrap = true;
				GuiArrStyle [Number_ListView, 9].alignment = TextAnchor.UpperLeft; // Поменять выравнивание текста
				GuiArrStyle [Number_ListView, 9].normal.textColor = Color.black;

				// Редактируемая колонка
				GuiArrStyle [Number_ListView, 10].normal.background = MakeTex (50, 50, new Color (0, 0, 0, 1));
				//GuiArrStyle[Number_ListView, 10].fontSize = 32;
				GuiArrStyle [Number_ListView, 10].wordWrap = true;
				GuiArrStyle [Number_ListView, 10].normal.textColor = Color.white;

				// Цвет разделителя колонок
				GuiArrStyle [Number_ListView, 5].normal.background = MakeTex (50, 50, new Color (0, 0, 0, 1));
				//GuiArrStyle[Number_ListView, 5].fontSize = 32;
				GuiArrStyle [Number_ListView, 5].normal.textColor = Color.white;

				// Цвет квадрата с активным "ListView"
				GuiArrStyle [Number_ListView, 11].normal.background = MakeTex (50, 50, new Color (0, 0, 0, 0.7f));
				//GuiArrStyle[Number_ListView, 11].fontSize = 32;
				GuiArrStyle [Number_ListView, 11].normal.textColor = Color.white;

				// Цвет квадрата с не активным "ListView"
				GuiArrStyle [Number_ListView, 12].normal.background = MakeTex (50, 50, new Color (0.5f, 0.5f, 0.5f, 0.7f));
				//GuiArrStyle[Number_ListView, 12].fontSize = 32;
				GuiArrStyle [Number_ListView, 12].normal.textColor = Color.white;
				////////////////////////////////////////////////////////////////////////
				FirstCreateGUI = true; // false-если первый цикл GUI			
			}
		}
		return true;
	}

	private Texture2D MakeTex(float width1, float height1 ,Color col) // Создать текстуру определенного цвета
	{				
		int width = Mathf.FloorToInt (width1);
		int height = Mathf.FloorToInt (height1);
		Texture2D result = new Texture2D(width, height);
		result.filterMode = FilterMode.Point; // Для четкой отрисовки
		result.wrapMode = TextureWrapMode.Clamp;
		if ((width > 0) & (height > 0)) {
			Color[] pix = new Color[width * height];

			for (int i = 0; i < pix.Length; i++)
				pix [i] = col;
		
			result.SetPixels (pix);
			result.Apply ();
		}
		return result;
	}

	private Texture2D MakeTexDraw(Texture2D result, float width1, float height1 , Rect rect1 ,Color col) // Зарисовать прямоугольник на текстуре цветом
	{
		if ((result.width > 0) & (result.height > 0)) {
			int width = Mathf.FloorToInt (width1);
			int height = Mathf.FloorToInt (height1);
			Color[] pix = result.GetPixels ();

			for (int i = Mathf.FloorToInt (rect1.y); i < Mathf.FloorToInt (rect1.yMax); i++) {
				for (int j = Mathf.FloorToInt (rect1.x); j < Mathf.FloorToInt (rect1.xMax); j++) {
					pix [(height - 1 - i) * width + j] = col;
				}
			}
			result.SetPixels (pix);		
			result.Apply ();
		}
		return result;
	}		

	public bool ChangeTextByWheel() { // Поменять текст колесиком мыши
		if (Input.GetAxis ("Mouse ScrollWheel") != 0) { // Если колесико мыши прокручено
			if (rect_SaveLoad [3].Contains (Event.current.mousePosition)) { // Если курсор над указанной позицией на экране
				if (Time.fixedTime > timeMouseWheel) {							
					if (Input.GetAxis ("Mouse ScrollWheel") > 0) { // Если колесико мыши прокручено от себя (вверх)
						timeMouseWheel = 1;
					} else if (Input.GetAxis ("Mouse ScrollWheel") < 0) { // Если колесико мыши прокручено на себя (вниз)
						timeMouseWheel = -1;
					}

					LoadTables [0] = Regex.Replace (LoadTables [0], "[^0-9]", ""); // Только числа

					float dhdhdhfdhdf = 0;
					float.TryParse (LoadTables [0], out dhdhdhfdhdf);

					dhdhdhfdhdf = dhdhdhfdhdf + 1 * timeMouseWheel;
					LoadTables [0] = dhdhdhfdhdf.ToString (); // Только числа
					timeMouseWheel = Time.fixedTime + 0.1f;
				}				
			} else if (rect_SaveLoad [2].Contains (Event.current.mousePosition)) { // Если курсор над указанной позицией на экране
				if (Time.fixedTime > timeMouseWheel) {
					if (Input.GetAxis ("Mouse ScrollWheel") > 0) { // Если колесико мыши прокручено от себя (вверх)
						timeMouseWheel = 1;
					} else if (Input.GetAxis ("Mouse ScrollWheel") < 0) { // Если колесико мыши прокручено на себя (вниз)
						timeMouseWheel = -1;
					}

					SaveTables [0] = Regex.Replace (SaveTables [0], "[^0-9]", ""); // Только числа

					float dhdhdhfdhdf = 0;
					float.TryParse (SaveTables [0], out dhdhdhfdhdf);

					dhdhdhfdhdf = dhdhdhfdhdf + 1 * timeMouseWheel;
					SaveTables [0] = dhdhdhfdhdf.ToString (); // Только числа
					timeMouseWheel = Time.fixedTime + 0.1f;			
				}				

			}
		}
		return true;
	}

	public bool CheckListView () { // Проверка взаимодействия с ListView
		if (MouseDoubleClick [Number_ListView] == 1) { // Промежуток
			if (Time.fixedTime > timeMouseClick [Number_ListView]) {									
				timeMouseClick [Number_ListView] = Time.fixedTime + 0.5f;
				MouseDoubleClick [Number_ListView] = 2;
				//print ("Ожидается 2 нажатие");
			}
		} else if (MouseDoubleClick [Number_ListView] > 1) { // Вышло время двойного нажатия
			if (Time.fixedTime > (timeMouseClick [Number_ListView] + 0.5f)) {
				MouseDoubleClick [Number_ListView] = 0;	
				//print ("Сброс");		
			}
		}			

		if (Input.GetMouseButton (0)) { // Если нажата левая кнопка мыши	
			if (MouseLeftClick [Number_ListView] == 0) { // Не повторять процедуру дважды
				MouseLeftClick [Number_ListView] = 1; // 1-Если левая кнопка мыши была нажата, 0-если кнопка мыши не нажата
				if (Rect_Scroll [Number_ListView, 1].Contains (new Vector2 (Input.mousePosition.x,
					    (Screen.height - Input.mousePosition.y)))) { // Если в пределах таблицы
					ClickedOnList = 1; // Если -1, то ни один ListView не выделен, 1-ListView выделен

					if (ListViewSelected != Number_ListView) {	
						timeKeyPressed [0] = Time.fixedTime + 0.5f;
						ListViewSelected = Number_ListView; // Выделен ListView "Number_ListView"
					}

					if (!CMrectangle.Contains (new Vector2 (Input.mousePosition.x,
						    (Screen.height - Input.mousePosition.y)))) { // Если не на контекстном меню											
						MouseRightClick = 0; // 1-нажата правая кнопка мыши, 0-кнопка мыши не нажата
						CMrectangle = new Rect (0, 0, 0, 0);

						if (!Rect_Scroll [Number_ListView, 5].Contains (Event.current.mousePosition)) { // Если не на редактируемой ячейке											
							if (Rect_Scroll [Number_ListView, 2].Contains (new Vector2 (Input.mousePosition.x,
								    (Screen.height - Input.mousePosition.y)))) {

								clickPosition [Number_ListView] = new Vector2 (Input.mousePosition.x - Rect_Scroll [Number_ListView, 1].x + scrollPosition [Number_ListView].x,
									((Screen.height - Input.mousePosition.y) - Rect_Scroll [Number_ListView, 1].y) + scrollPosition [Number_ListView].y + 1.5f);

								tNumOfColumn0 = 0; // На какую колонку нажата мышка

								for (int i = 0; i < tColumnProperty [Number_ListView, 0]; i++) {
									if (clickPosition [Number_ListView].x <= tColumnRect [Number_ListView, i, 1].xMax) {
										tNumOfColumn0 = i; // На какую колонку нажата мышка
										break;
									}
								}

								tNumOfItem0 = 0; // Номер ряда

								for (int i = 0; i < tItemProperty [Number_ListView, 0]; i++) {
									if (clickPosition [Number_ListView].y <= tItemRect [Number_ListView, i, 1].yMax) {
										tNumOfItem0 = i; // На какой ряд нажата мышка
										break;
									}
								}

								if (tNumOfItem0 < 0)
									tNumOfItem0 = 0;
								if (tNumOfItem0 > tItemProperty [Number_ListView, 0] - 1)
									tNumOfItem0 = Mathf.FloorToInt (tItemProperty [Number_ListView, 0] - 1); 
								if (tNumOfColumn0 < 0)
									tNumOfColumn0 = 0;
								if (tNumOfColumn0 > tColumnProperty [Number_ListView, 0] - 1)
									tNumOfColumn0 = Mathf.FloorToInt (tColumnProperty [Number_ListView, 0] - 1); 

								otherbutton1 = false;
								// Если выделена другая колонка или ряд
								if ((tNumOfColumn [Number_ListView] != tNumOfColumn0) | (tNumOfItem [Number_ListView] != tNumOfItem0)) {
									otherbutton1 = true;
								} else { // Если та же кнопка
									if (MouseDoubleClick [Number_ListView] == 0) { // Первое нажатие
										timeMouseClick [Number_ListView] = Time.fixedTime + 0.1f;  
										MouseDoubleClick [Number_ListView] = 1;
									} else if ((MouseDoubleClick [Number_ListView] == 2) &
										(!EditInField [Number_ListView]) &
										(!EditInColumn [Number_ListView])) { // Второе нажатие
										ChangingText [Number_ListView] = tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]]; // Запомнить не измененный текст
										if (Show_Hide [4] == true) { // Возможность редактировать ячейку
											EditSomeField = 1;
											EditInField [Number_ListView] = true;
											CMchanged [ListViewSelected] = 1;
											Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
												tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
										}
										timeMouseClick [Number_ListView] = Time.fixedTime;  
										MouseDoubleClick [Number_ListView] = 3;
									}
								}
									
								Rect_Scroll [Number_ListView, 4] = new Rect (
									tColumnRect [Number_ListView, tNumOfColumn0, 1].x, 
									tItemRect [Number_ListView, tNumOfItem0, 1].y,
									tColumnRect [Number_ListView, tNumOfColumn0, 1].width, 
									tItemRect [Number_ListView, tNumOfItem0, 1].height);

								if (Rect_Scroll [Number_ListView, 4].Contains (clickPosition [Number_ListView])) {
									// Если выделена другая колонка или ряд
									if (otherbutton1 == true) {	
										SaveChanges1 ();

										EditInColumn [Number_ListView] = false;
										EditInField [Number_ListView] = false;	

										tNumOfColumn [Number_ListView] = tNumOfColumn0;
										tNumOfItem [Number_ListView] = tNumOfItem0;

										ShowItem1 (); // Показать выделенную колонку или ряд если за пределами прорисовки ************		
										print ("ListView: " + Number_ListView + "  |Cursor|  Колонка: " + tNumOfColumn [Number_ListView] + "  Ряд: " + tNumOfItem [Number_ListView] + "  Текст: " + tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]]);
									}
								} else {
									SaveChanges1 ();

									EditInColumn [Number_ListView] = false;
									EditInField [Number_ListView] = false;	
								}
							}
					// Если можно выбирать ячейку нажатием на колонку и мышка нажата на колонку
					else if ((Show_Hide [11] == true) & (Rect_Scroll [Number_ListView, 0].Contains
						(new Vector2 (Input.mousePosition.x, (Screen.height - Input.mousePosition.y))))) {

								clickPosition [Number_ListView] = new Vector2 (Input.mousePosition.x - Rect_Scroll [Number_ListView, 1].x + scrollPosition [Number_ListView].x,
									((Screen.height - Input.mousePosition.y) - Rect_Scroll [Number_ListView, 1].y) + scrollPosition [Number_ListView].y + 1.5f);

								tNumOfColumn0 = 0; // На какую колонку нажата мышка

								for (int i = 0; i < tColumnProperty [Number_ListView, 0]; i++) {
									if (clickPosition [Number_ListView].x <= tColumnRect [Number_ListView, i, 1].xMax) {
										tNumOfColumn0 = i; // На какую колонку нажата мышка
										break;
									}
								}

								if (tNumOfColumn0 < 0)
									tNumOfColumn0 = 0;
								if (tNumOfColumn0 > tColumnProperty [Number_ListView, 0] - 1)
									tNumOfColumn0 = Mathf.FloorToInt (tColumnProperty [Number_ListView, 0] - 1); 

								otherbutton1 = false;
								// Если выделена другая колонка
								if (tNumOfColumn [Number_ListView] != tNumOfColumn0) {
									otherbutton1 = true;
								} else { // Если та же колонка
									if (MouseDoubleClick [Number_ListView] == 0) { // Первое нажатие
										timeMouseClick [Number_ListView] = Time.fixedTime + 0.1f;  
										MouseDoubleClick [Number_ListView] = 1;
									} else if ((MouseDoubleClick [Number_ListView] == 2) &
										(!EditInField [Number_ListView]) &
										(!EditInColumn [Number_ListView])) { // Второе нажатие
										ChangingText [Number_ListView] = tNameOfColumns [Number_ListView, tNumOfColumn [Number_ListView]]; // Запомнить не измененный текст
										if (Show_Hide [8] == true) { // Возможность редактировать колонку
											EditSomeField = 2;
											EditInColumn [Number_ListView] = true;	
											CMchanged [ListViewSelected] = 2;
											Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
												tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
										}
										timeMouseClick [Number_ListView] = Time.fixedTime;  
										MouseDoubleClick [Number_ListView] = 3;
									}
								}

								Rect_Scroll [Number_ListView, 4] = new Rect (
									tColumnRect [Number_ListView, tNumOfColumn0, 2].x, 
									scrollPosition [Number_ListView].y,
									tColumnRect [Number_ListView, tNumOfColumn0, 2].width, 
									tColumnRect [Number_ListView, tNumOfColumn0, 2].height);

								if (Rect_Scroll [Number_ListView, 4].Contains (clickPosition [Number_ListView])) {
									// Если выделена другая колонка
									if (otherbutton1 == true) {	
										SaveChanges1 ();

										EditInColumn [Number_ListView] = false;
										EditInField [Number_ListView] = false;	

										tNumOfColumn [Number_ListView] = tNumOfColumn0;

										print ("ListView: " + Number_ListView + "  |Cursor|  Колонка: " + tNumOfColumn [Number_ListView] + "  Текст: " + tNameOfColumns [Number_ListView, tNumOfColumn [Number_ListView]]);
									}
								} else {
									SaveChanges1 ();

									EditInColumn [Number_ListView] = false;
									EditInField [Number_ListView] = false;	
								}
							}
						}		
					} else { // Если на контекстном меню	
						SimpleVector = new Vector2 (Input.mousePosition.x - CMrectangle.x,
							(Screen.height - Input.mousePosition.y) - CMrectangle.y);
						selGridInt = Mathf.FloorToInt (SimpleVector.y / (CMrectangle.height / selStrings.Length - 1)); // Нажата кнопка
						ContextMenu_PreAction (selGridInt,ListViewSelected, 
							tNumOfColumn [ListViewSelected], 
							tNumOfItem [ListViewSelected]); // Действие контекстного меню	
					}
				} else {
					SimpleVector = new Vector2 (Input.mousePosition.x, (Screen.height - Input.mousePosition.y));
					// Если не кнопки добавить, удалить ряд
					if ((!rect_AddDelRowColumn [0].Contains (SimpleVector)) &
					    (!rect_AddDelRowColumn [1].Contains (SimpleVector)) &
					    (!rect_AddDelRowColumn [2].Contains (SimpleVector)) &
					    (!rect_AddDelRowColumn [3].Contains (SimpleVector))) {
						if (Number_ListView == Count_ListView - 1) {
							if (ListViewSelected > -1) {
								//if (ListViewSelected == Number_ListView) {
								if (CMrectangle.Contains (new Vector2 (Input.mousePosition.x,
									    (Screen.height - Input.mousePosition.y)))) { // Если на контекстном меню	
									CMoutOfTable = 1; // 1-нажата кнопка контекстного меню за пределами таблицы
									SimpleVector = new Vector2 (Input.mousePosition.x - CMrectangle.x,
										(Screen.height - Input.mousePosition.y) - CMrectangle.y);
									selGridInt = Mathf.FloorToInt (SimpleVector.y / (CMrectangle.height / selStrings.Length - 1)); // Нажата кнопка
									ContextMenu_PreAction (selGridInt, ListViewSelected, 
										tNumOfColumn [ListViewSelected], 
										tNumOfItem [ListViewSelected]); // Действие контекстного меню	
								} else if (CMoutOfTable == 0) { // Если не на контекстном меню	
					
									MouseRightClick = 0; // 1-нажата правая кнопка мыши, 0-кнопка мыши не нажата
									CMrectangle = new Rect (0, 0, 0, 0);

									// Отключить редактирование если мышка нажата за пределами всех компонентов ListView
									if (ClickedOnList == -1) { // Если ни один ListView не выделен
										ListViewSelected = -1; // ListView не выделен
										EditFieldToSimple (); // Закрыть все редактируемые поля
									}
								}								
							}												
						}										
					}
				}
			}
		} else if (Input.GetMouseButtonDown (1)) { // Если нажата правая кнопка мыши	
			if (ListViewSelected > -1) {
				if ((EditInColumn [ListViewSelected] == false) & 
					(EditInField [ListViewSelected] == false)) {	
				if (Rect_Scroll [ListViewSelected, 1].Contains (new Vector2 (Input.mousePosition.x,
					    (Screen.height - Input.mousePosition.y)))) { // Если в пределах таблицы				
					MouseRightClick = 1; // 1-нажата правая кнопка мыши, 0-кнопка мыши не нажата
					ShowContextMenu (); // Определить координаты контекстного меню	
				}
			}
			}
		}			
		else {
			CMoutOfTable = 0; // 1-нажата кнопка контекстного меню за пределами таблицы

			MouseLeftClick[Number_ListView] = 0; // 1-Если левая кнопка мыши была нажата, 0-если кнопка мыши не нажата
			if (Rect_Scroll [Number_ListView, 1].Contains (new Vector2 (Input.mousePosition.x,
				    (Screen.height - Input.mousePosition.y)))) {
				if (!CMrectangle.Contains (new Vector2 (Input.mousePosition.x,
					(Screen.height - Input.mousePosition.y)))) { // Если не на контекстном меню	
					if (!Rect_Scroll [Number_ListView, 5].Contains (Event.current.mousePosition)) { // Если не на редактируемой ячейке								
						if (Rect_Scroll [Number_ListView, 2].Contains (new Vector2 (Input.mousePosition.x,
							   (Screen.height - Input.mousePosition.y)))) {	

							clickPosition [Number_ListView] = new Vector2 (Input.mousePosition.x - Rect_Scroll [Number_ListView, 1].x + scrollPosition [Number_ListView].x,
								((Screen.height - Input.mousePosition.y) - Rect_Scroll [Number_ListView, 1].y) + scrollPosition [Number_ListView].y + 1.5f);

							tNumOfColumn0 = 0; // На какую колонку наведена мышка

							for (int i = 0; i < tColumnProperty [Number_ListView, 0]; i++) {
								if (clickPosition [Number_ListView].x <= tColumnRect [Number_ListView, i, 1].xMax) {
									tNumOfColumn0 = i; // На какую колонку наведена мышка
									break;
								}
							}

							tNumOfItem0 = 0; // Номер ряда

							for (int i = 0; i < tItemProperty [Number_ListView, 0]; i++) {
								if (clickPosition [Number_ListView].y <= tItemRect [Number_ListView, i, 1].yMax) {
									tNumOfItem0 = i; // На какой ряд наведена мышка
									break;
								}
							}

							if (tNumOfItem0 < 0)
								tNumOfItem0 = 0;
							if (tNumOfItem0 > tItemProperty [Number_ListView, 0] - 1)
								tNumOfItem0 = Mathf.FloorToInt (tItemProperty [Number_ListView, 0] - 1); 
							if (tNumOfColumn0 < 0)
								tNumOfColumn0 = 0;
							if (tNumOfColumn0 > tColumnProperty [Number_ListView, 0] - 1)
								tNumOfColumn0 = Mathf.FloorToInt (tColumnProperty [Number_ListView, 0] - 1); 

							Rect_Scroll [Number_ListView, 4] = new Rect (
								tColumnRect [Number_ListView, tNumOfColumn0, 1].x, 
								tItemRect [Number_ListView, tNumOfItem0, 1].y,
								tColumnRect [Number_ListView, tNumOfColumn0, 1].width, 
								tItemRect [Number_ListView, tNumOfItem0, 1].height);


							if (Rect_Scroll [Number_ListView, 4].Contains (clickPosition [Number_ListView])) {
								MovedOnListItem = 1; // Если -1, то ни на одну ячейку ListView не наведен курсор, 1-курсор над ячейкой ListView
								// Если выделена другая колонка или ряд
								if ((ListViewItemHint [1] != tNumOfColumn0) | (ListViewItemHint [2] != tNumOfItem0)) {	
									HintByMove = 0; // 0-Подсказка от курсора, 1-подсказка от клавиш
									ListViewItemHint [0] = Number_ListView; // Номер ListView
									ListViewItemHint [1] = tNumOfColumn0; // Номер колонки для отображения подсказки
									ListViewItemHint [2] = tNumOfItem0; // Номер ряда для отображения подсказки

									ListViewColumnHint [1] = -1; // Номер колонки для отображения подсказки

									float rect1x = Rect_Scroll [ListViewItemHint [0], 1].x + Rect_Scroll [ListViewItemHint [0], 4].x +
									              Rect_Scroll [ListViewItemHint [0], 4].width + tItemProperty [ListViewItemHint [0], 1] - scrollPosition [ListViewItemHint [0]].x;
									if (rect1x > Rect_Scroll [ListViewItemHint [0], 2].xMax) { // Если левый край подсказки выходит за пределы таблицы
										rect1x = Rect_Scroll [ListViewItemHint [0], 2].xMax;
									}
									// Определить размеры подсказки
									SimpleVector = GuiHintItemStyle.CalcSize (new GUIContent (tNameOfItems [ListViewItemHint [0], ListViewItemHint [1], ListViewItemHint [2]]));

									float rect1w = Screen.width - rect1x - 10; // Расстояние от левой позиции подсказки до края приложения

									if (SimpleVector.x > rect1w) { // Если выходит за пределы экрана
										SimpleVector = new Vector2 (rect1w, GuiHintItemStyle.CalcHeight (new GUIContent (
											tNameOfItems [ListViewItemHint [0], ListViewItemHint [1], ListViewItemHint [2]]), rect1w));
									}

									float rect1y = Rect_Scroll [ListViewItemHint [0], 1].y + Rect_Scroll [ListViewItemHint [0], 4].y - scrollPosition [ListViewItemHint [0]].y;

									if (rect1y < Rect_Scroll [ListViewItemHint [0], 1].y + tColumnRect [ListViewItemHint [0], ListViewItemHint [1], 0].height)
										rect1y = Rect_Scroll [ListViewItemHint [0], 1].y + tColumnRect [ListViewItemHint [0], ListViewItemHint [1], 0].height;

									HintItemSize = new Rect (rect1x, rect1y,
										SimpleVector.x + 5, SimpleVector.y); // Позиция, размеры подсказки
									timeShowHint = Time.fixedTime + 0.7f;  // Показывать подсказку с задержкой
									print ("ItemHint^ ListView: " + ListViewItemHint [0] + "  |Cursor|  Колонка: " + ListViewItemHint [1] + "  Ряд: " + ListViewItemHint [2] + "  Текст: " + tNameOfItems [ListViewItemHint [0], ListViewItemHint [1], ListViewItemHint [2]]);
								}
							} else {
								// Отключить подсказку если мышка за пределами всех компонентов ListView
								if ((ListViewItemHint [1] > -1) &
								   (Number_ListView == Count_ListView - 1) &
								   (MovedOnListItem == -1)) { // Если ни на один ListView не наведен курсор
									MovedOnListItem = -1; // Ни на одну ячейку ListView не наведен курсор
									//ListViewItemHint[0] = -1; // Номер ListView
									ListViewItemHint [1] = -1; // Номер колонки для отображения подсказки
									ListViewItemHint [2] = -1; // Номер ряда для отображения подсказки

									ListViewColumnHint [1] = -1; // Номер колонки для отображения подсказки
								}					
							}
						}
					// Если мышка над колонкой
					else if (Rect_Scroll [Number_ListView, 0].Contains
						(new Vector2 (Input.mousePosition.x, (Screen.height - Input.mousePosition.y)))) {

							clickPosition [Number_ListView] = new Vector2 (Input.mousePosition.x - Rect_Scroll [Number_ListView, 1].x + scrollPosition [Number_ListView].x,
								((Screen.height - Input.mousePosition.y) - Rect_Scroll [Number_ListView, 1].y) + scrollPosition [Number_ListView].y + 1.5f);

							tNumOfColumn0 = 0; // На какую колонку нажата мышка

							for (int i = 0; i < tColumnProperty [Number_ListView, 0]; i++) {
								if (clickPosition [Number_ListView].x <= tColumnRect [Number_ListView, i, 1].xMax) {
									tNumOfColumn0 = i; // На какую колонку нажата мышка
									break;
								}
							}

							if (tNumOfColumn0 < 0)
								tNumOfColumn0 = 0;
							if (tNumOfColumn0 > tColumnProperty [Number_ListView, 0] - 1)
								tNumOfColumn0 = Mathf.FloorToInt (tColumnProperty [Number_ListView, 0] - 1); 

							Rect_Scroll [Number_ListView, 4] = new Rect (
								tColumnRect [Number_ListView, tNumOfColumn0, 0].x, 
								scrollPosition [Number_ListView].y,
								tColumnRect [Number_ListView, tNumOfColumn0, 0].width, 
								tColumnRect [Number_ListView, tNumOfColumn0, 0].height);

							if (Rect_Scroll [Number_ListView, 4].Contains (clickPosition [Number_ListView])) {
								MovedOnListColumn = 1; // Если -1, то ни на одну колонку ListView не наведен курсор, 1-курсор над колонкой ListView
								// Если выделена другая колонка
								if (ListViewColumnHint [1] != tNumOfColumn0) {	
									HintByMove = 0; // 0-Подсказка от курсора, 1-подсказка от клавиш
									ListViewColumnHint [0] = Number_ListView; // Номер ListView
									ListViewColumnHint [1] = tNumOfColumn0; // Номер колонки для отображения подсказки

									ListViewItemHint [1] = -1; // Номер колонки для отображения подсказки
									ListViewItemHint [2] = -1; // Номер ряда для отображения подсказки

									float rect1x = Rect_Scroll [ListViewColumnHint [0], 1].x + Rect_Scroll [ListViewColumnHint [0], 4].x +
									              Rect_Scroll [ListViewColumnHint [0], 4].width - scrollPosition [ListViewColumnHint [0]].x;
									if (rect1x > Rect_Scroll [ListViewColumnHint [0], 2].xMax) { // Если левый край подсказки выходит за пределы таблицы
										rect1x = Rect_Scroll [ListViewColumnHint [0], 2].xMax;
									}
									// Определить размеры подсказки
									SimpleVector = GuiHintColumnStyle.CalcSize (new GUIContent (tNameOfColumns [ListViewColumnHint [0], ListViewColumnHint [1]]));

									float rect1w = Screen.width - rect1x - 10; // Расстояние от левой позиции подсказки до края приложения

									if (SimpleVector.x > rect1w) { // Если выходит за пределы экрана
										SimpleVector = new Vector2 (rect1w, GuiHintColumnStyle.CalcHeight (new GUIContent (
											tNameOfColumns [ListViewColumnHint [0], ListViewColumnHint [1]]), rect1w));
									}

									float rect1y = Rect_Scroll [ListViewColumnHint [0], 1].y + Rect_Scroll [ListViewColumnHint [0], 4].y - scrollPosition [ListViewColumnHint [0]].y;

									HintColumnSize = new Rect (rect1x, rect1y,
										SimpleVector.x + 5, SimpleVector.y); // Позиция, размеры подсказки
									timeShowHint = Time.fixedTime + 0.7f;  // Показывать подсказку с задержкой
									print ("ColumnHint^ ListView: " + ListViewColumnHint [0] + "  |Cursor|  Колонка: " + ListViewColumnHint [1] + "  Текст: " + tNameOfColumns [ListViewColumnHint [0], ListViewColumnHint [1]]);
								}
							} else {
								// Отключить подсказку если мышка за пределами всех компонентов ListView
								if ((ListViewColumnHint [1] > -1) &
								   (Number_ListView == Count_ListView - 1) &
								   (MovedOnListColumn == -1)) { // Если ни на один ListView не наведен курсор
									MovedOnListColumn = -1; // Ни на одну колонку ListView не наведен курсор
									//ListViewColumnHint[0] = -1; // Номер ListView
									ListViewColumnHint [1] = -1; // Номер колонки для отображения подсказки

									ListViewItemHint [1] = -1; // Номер колонки для отображения подсказки
									ListViewItemHint [2] = -1; // Номер ряда для отображения подсказки
								}	
							}							
						}
					}		
				}
			} else {
				if (HintByMove == 0) { // Если подсказка от курсора
					// Отключить подсказку если мышка за пределами всех компонентов ListView
					if ((ListViewItemHint [0] > -1) &
					   (Number_ListView == Count_ListView - 1) &
					   (MovedOnListItem == -1)) { // Если ни на одну ячейку ListView не наведен курсор
						MovedOnListItem = -1; // Ни на одну ячейку ListView не наведен курсор
						ListViewItemHint [0] = -1; // Номер ListView
						ListViewItemHint [1] = -1; // Номер колонки для отображения подсказки
						ListViewItemHint [2] = -1; // Номер ряда для отображения подсказки
					}	
					// Отключить подсказку если мышка за пределами всех компонентов ListView
					if ((ListViewColumnHint [1] > -1) &
					   (Number_ListView == Count_ListView - 1) &
					   (MovedOnListColumn == -1)) { // Если ни на один ListView не наведен курсор
						MovedOnListColumn = -1; // Ни на одну колонку ListView не наведен курсор
						ListViewColumnHint [0] = -1; // Номер ListView
						ListViewColumnHint [1] = -1; // Номер колонки для отображения подсказки
					}	
				}
			}
		}

		if ((EditInField [Number_ListView]==false) & // Если ячейка не редактируется
			(EditInColumn [Number_ListView]==false) & // Если колонка не редактируется
			(ListViewSelected == Number_ListView)) { // Если выделенный ListView

				// Если нажат "Ctrl" и нет окна контекстного меню
				if ((MouseRightClick == 0) &
				   ((Input.GetKey (KeyCode.LeftControl)) |
				   (Input.GetKey (KeyCode.RightControl)))) {
					if (Time.fixedTime > timeLeft [ListViewSelected]) {
						if (((Input.GetKey (KeyCode.LeftShift)) |
						   (Input.GetKey (KeyCode.RightShift))) &
						   (Input.GetKey (KeyCode.Z))) { // Вернуть изменения
							timeLeft [ListViewSelected] = Time.fixedTime + 0.2f;  // Засечь время, чтобы не перескакивать через ряды
							ContextMenu_PreAction (5, ListViewSelected, 
								tNumOfColumn [ListViewSelected], 
								tNumOfItem [ListViewSelected]);						
						} else if (Input.GetKey (KeyCode.X)) { // Вырезать
							if (CMbutton [ListViewSelected] != 0) {
								ContextMenu_PreAction (0, ListViewSelected, 
									tNumOfColumn [ListViewSelected], 
									tNumOfItem [ListViewSelected]); // Действие контекстного меню
							}
						} else if (Input.GetKey (KeyCode.C)) { // Копировать	
							if (CMbutton [ListViewSelected] != 1) {
								ContextMenu_PreAction (1, ListViewSelected, 
									tNumOfColumn [ListViewSelected], 
									tNumOfItem [ListViewSelected]);	
							}
						} else if (Input.GetKey (KeyCode.V)) { // Вставить
							if (CMbutton [ListViewSelected] != 2) {
								ContextMenu_PreAction (2, ListViewSelected, 
									tNumOfColumn [ListViewSelected], 
									tNumOfItem [ListViewSelected]);								
							}
						} else if (Input.GetKey (KeyCode.B)) { // Поменять текст ячейки с буфером обмена
							if (CMbutton [ListViewSelected] != 3) {
								ContextMenu_PreAction (3, ListViewSelected, 
									tNumOfColumn [ListViewSelected], 
									tNumOfItem [ListViewSelected]);	
							}
						} else if (Input.GetKey (KeyCode.Z)) { // Отменить изменения
							timeLeft [ListViewSelected] = Time.fixedTime + 0.2f;  // Засечь время, чтобы не перескакивать через ряды
							ContextMenu_PreAction (4, ListViewSelected, 
								tNumOfColumn [ListViewSelected], 
								tNumOfItem [ListViewSelected]);	
						} else if (CMbutton [ListViewSelected] > -1) {
							CMbutton [ListViewSelected] = -1;
						}
					}
				} else if (CMbutton [ListViewSelected] > -1) {
					CMbutton [ListViewSelected] = -1;			
				}

				// Если нажаты стрелки на клавиатуре
			if ((Input.GetKey (KeyCode.UpArrow)) |
			     (Input.GetKey (KeyCode.DownArrow)) |
			     (Input.GetKey (KeyCode.LeftArrow)) |
			     (Input.GetKey (KeyCode.RightArrow))) {
				if (Time.fixedTime > timeLeft [Number_ListView]) {
					timeLeft [Number_ListView] = Time.fixedTime + 0.2f;  // Засечь время, чтобы не перескакивать через ряды
					tNumOfItem0 = tNumOfItem [Number_ListView];
					tNumOfColumn0 = tNumOfColumn [Number_ListView];

					// Если клавиша вверх
					if (Input.GetKey (KeyCode.UpArrow)) {
						tNumOfItem0 = tNumOfItem [Number_ListView] - 1;
						if (tNumOfItem0 < 0)
							tNumOfItem0 = 0;
					}
					// Если клавиша вниз
					if (Input.GetKey (KeyCode.DownArrow)) {
						tNumOfItem0 = tNumOfItem [Number_ListView] + 1;
						if (tNumOfItem0 > tItemProperty [Number_ListView, 0] - 1)
							tNumOfItem0 = Mathf.FloorToInt (tItemProperty [Number_ListView, 0] - 1); 
					}
					// Если клавиша влево
					if (Input.GetKey (KeyCode.LeftArrow)) {
						tNumOfColumn0 = tNumOfColumn [Number_ListView] - 1;
						if (tNumOfColumn0 < 0)
							tNumOfColumn0 = 0;
					}
					// Если клавиша вправо
					if (Input.GetKey (KeyCode.RightArrow)) {						
						tNumOfColumn0 = tNumOfColumn [Number_ListView] + 1;
						if (tNumOfColumn0 > tColumnProperty [Number_ListView, 0] - 1)
							tNumOfColumn0 = Mathf.FloorToInt (tColumnProperty [Number_ListView, 0] - 1); 
					}

					// Если выделена другая колонка или ряд
					if ((tNumOfColumn [Number_ListView] != tNumOfColumn0) | (tNumOfItem [Number_ListView] != tNumOfItem0)) {																					

						tNumOfColumn [Number_ListView] = tNumOfColumn0;
						tNumOfItem [Number_ListView] = tNumOfItem0;

						ShowItem1 (); // Показать выделенную колонку или ряд если за пределами прорисовки ************		
						print ("ListView: " + Number_ListView + "  |Key|  Колонка: " + tNumOfColumn [Number_ListView] + "  Ряд: " + tNumOfItem [Number_ListView] + "  Текст: " + tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]]);

						ShowHintAfterMove (); // Показывать подсказку после перемещения клавишами	
					}
				}
			}
		}
		return true;
	}

	public bool EditFieldToSimple() { // Закрыть все редактируемые поля
		if (EditSomeField > 0) {
			EditSomeField = 0;
			for (int i = 0; i <= Count_ListView - 1; i++) {
				if ((Show_Hide [9] == false) & (EditInColumn [i] == true)) { // Вернуть не измененный текст колонки
					tNameOfColumns [i, tNumOfColumn [i]] = ChangingText [i];
				} else if ((Show_Hide [5] == false) & (EditInField [i] == true)) { // Вернуть не измененный текст ячейки
					tNameOfItems [i, tNumOfColumn [i], tNumOfItem [i]] = ChangingText [i];
				} else if ((EditInColumn [i] == true) | (EditInField [i] == true)) {	
					Save_EditInField (i, tNumOfColumn [i], tNumOfItem [i]); // Сохранить свойства текущей таблицы "ListViewSelected"										
					EditInColumn [i] = false;
					EditInField [i] = false;	
				}									
			}
		}
		return true;
	}

	public bool ShowHintAfterMove () { // Показывать подсказку после перемещения клавишами	
		if (Show_Hide[12] == true) { // Если нужно показывать подсказку после перемещения клавишами
			HintByMove = 1; // 0-Подсказка от курсора, 1-подсказка от клавиш

			Rect_Scroll [ListViewSelected, 4] = new Rect (
				tColumnRect [ListViewSelected, tNumOfColumn [ListViewSelected], 1].x, 
				tItemRect [ListViewSelected, tNumOfItem [ListViewSelected], 1].y,
				tColumnRect [ListViewSelected, tNumOfColumn [ListViewSelected], 1].width, 
				tItemRect [ListViewSelected, tNumOfItem [ListViewSelected], 1].height);

				ListViewItemHint [0] = ListViewSelected; // Номер ListView
				ListViewItemHint [1] = tNumOfColumn [ListViewSelected]; // Номер колонки для отображения подсказки
				ListViewItemHint [2] = tNumOfItem [ListViewSelected]; // Номер ряда для отображения подсказки

				ListViewColumnHint [1] = -1; // Номер колонки для отображения подсказки

				float rect1x = Rect_Scroll [ListViewItemHint [0], 1].x + Rect_Scroll [ListViewItemHint [0], 4].x +
					Rect_Scroll [ListViewItemHint [0], 4].width + tItemProperty [ListViewItemHint [0], 1] - scrollPosition [ListViewItemHint [0]].x;
				if (rect1x > Rect_Scroll [ListViewItemHint [0], 2].xMax) { // Если левый край подсказки выходит за пределы таблицы
					rect1x = Rect_Scroll [ListViewItemHint [0], 2].xMax;
				}
				// Определить размеры подсказки
				SimpleVector = GuiHintItemStyle.CalcSize (new GUIContent (tNameOfItems [ListViewItemHint [0], ListViewItemHint [1], ListViewItemHint [2]]));

				float rect1w = Screen.width - rect1x - 10; // Расстояние от левой позиции подсказки до края приложения

				if (SimpleVector.x > rect1w) { // Если выходит за пределы экрана
					SimpleVector = new Vector2 (rect1w, GuiHintItemStyle.CalcHeight (new GUIContent (
						tNameOfItems [ListViewItemHint [0], ListViewItemHint [1], ListViewItemHint [2]]), rect1w));
				}

				float rect1y = Rect_Scroll [ListViewItemHint [0], 1].y + Rect_Scroll [ListViewItemHint [0], 4].y - scrollPosition [ListViewItemHint [0]].y;

				if (rect1y < Rect_Scroll [ListViewItemHint [0], 1].y + tColumnRect [ListViewItemHint [0], ListViewItemHint [1], 0].height)
					rect1y = Rect_Scroll [ListViewItemHint [0], 1].y + tColumnRect [ListViewItemHint [0], ListViewItemHint [1], 0].height;

				HintItemSize = new Rect (rect1x, rect1y,
					SimpleVector.x + 5, SimpleVector.y); // Позиция, размеры подсказки
				timeShowHint = Time.fixedTime + 0.7f;  // Показывать подсказку с задержкой							
		}
		return true;
	}

	public bool ShowContextMenu () { // Определить координаты контекстного меню	
		if (Show_Hide[14] == true) { // Если нужно показывать контекстное меню
			int width1 = 90; // Ширина контекстного меню
			int height1 = 150; // Высота контекстного меню
			Rect_Scroll [ListViewSelected, 4] = new Rect (
				tColumnRect [ListViewSelected, tNumOfColumn [ListViewSelected], 1].x, 
				tItemRect [ListViewSelected, tNumOfItem [ListViewSelected], 1].y,
				tColumnRect [ListViewSelected, tNumOfColumn [ListViewSelected], 1].width, 
				tItemRect [ListViewSelected, tNumOfItem [ListViewSelected], 1].height);

			float rect1x = Rect_Scroll [ListViewSelected, 1].x + Rect_Scroll [ListViewSelected, 4].x +
				Rect_Scroll [ListViewSelected, 4].width + tItemProperty [ListViewSelected, 1] - scrollPosition [ListViewSelected].x;
			if (rect1x > Rect_Scroll [ListViewSelected, 2].xMax-CMrectangle.width) { // Если левый край подсказки выходит за пределы таблицы (справа)				
				// Если ячейка в пределах видимости
				if (Rect_Scroll [ListViewSelected, 4].x <
					Rect_Scroll [ListViewSelected, 1].x + Rect_Scroll [ListViewSelected, 2].width 
					+ scrollPosition [ListViewSelected].x) {
					rect1x = Rect_Scroll [ListViewSelected, 4].x
						- scrollPosition [ListViewSelected].x-CMrectangle.width;
				} else {
					rect1x = Rect_Scroll [ListViewSelected, 2].xMax-CMrectangle.width;
				}
			}

			if (rect1x < Rect_Scroll [ListViewSelected, 1].x) { // Если левый край подсказки выходит за пределы таблицы (слева)
				rect1x = Rect_Scroll [ListViewSelected, 1].x;
			}

			float rect1w = Screen.width - rect1x - 10; // Расстояние от левой позиции подсказки до края приложения

			if (width1 > rect1w) { // Если выходит за пределы экрана
				rect1x = Rect_Scroll [ListViewSelected, 1].x + Rect_Scroll [ListViewSelected, 4].x +
				-tItemProperty [ListViewSelected, 1] - scrollPosition [ListViewSelected].x - width1;
			}

			float rect1y = Rect_Scroll [ListViewSelected, 1].y + Rect_Scroll [ListViewSelected, 4].y - scrollPosition [ListViewSelected].y;

			if (rect1y < Rect_Scroll [ListViewSelected, 1].y + tColumnRect [ListViewSelected, 0, 0].height) // Если выше колонки
				rect1y = Rect_Scroll [ListViewSelected, 1].y + tColumnRect [ListViewSelected, 0, 0].height;

			if (rect1y > Rect_Scroll [ListViewSelected, 2].yMax-CMrectangle.height) // Если ниже таблицы
				rect1y = Rect_Scroll [ListViewSelected, 2].yMax-CMrectangle.height;

			CMrectangle = new Rect (rect1x, rect1y,
				width1, height1); // Позиция, размеры контекстного меню		
		}
		return true;
	}

	public bool VisibleArea () { // Определить кнопки в видимой области	
		for (int i = 0; i <= tColumnProperty [Number_ListView, 0] - 1; i++) {
			if (scrollPosition [Number_ListView].x < tColumnRect [Number_ListView, i, 0].xMax) {
				LPartVisibleColumn[Number_ListView] = Mathf.FloorToInt(scrollPosition [Number_ListView].x-tColumnRect [Number_ListView, i, 0].x); // Количество пикселей левой колонки за пределами таблицы
				ChangeVariables [Number_ListView, 0] = i; // Номер видимой колонки слева
				break;
			}
		}
		ChangeVariables [Number_ListView, 1] = Mathf.FloorToInt (tColumnProperty [Number_ListView, 0] - 1); // Номер видимой колонки справа
		for (int i = ChangeVariables [Number_ListView, 0]; i <= tColumnProperty [Number_ListView, 0] - 1; i++) {
			if (scrollPosition [Number_ListView].x + Rect_Scroll [Number_ListView, 2].width < tColumnRect [Number_ListView, i, 0].xMax) {
				ChangeVariables [Number_ListView, 1] = i; // Номер видимой колонки справа
				break;
			}
		}
		for (int i = 0; i <= tItemProperty [Number_ListView, 0] - 1; i++) {
			if (scrollPosition [Number_ListView].y < tItemRect [Number_ListView, i, 0].yMax) {
				ChangeVariables [Number_ListView, 2] = i; // Номер видимого ряда сверху
				break;
			}
		}
		ChangeVariables [Number_ListView, 3] = Mathf.FloorToInt (tItemProperty [Number_ListView, 0] - 1); // Номер видимого ряда снизу
		for (int i = ChangeVariables [Number_ListView, 2]; i <= tItemProperty [Number_ListView, 0] - 1; i++) {
			if (scrollPosition [Number_ListView].y + Rect_Scroll [Number_ListView, 2].height < tItemRect [Number_ListView, i, 0].yMax-tColumnRect [Number_ListView, 0, 0].height) {
				ChangeVariables [Number_ListView, 3] = i; // Номер видимого ряда снизу
				break;
			}
		}
		scrollPosition_check [Number_ListView] = scrollPosition [Number_ListView];
		//print (ChangeVariables [Number_ListView, 0] + "  " + ChangeVariables [Number_ListView, 1] + "  "
		//+ ChangeVariables [Number_ListView, 2] + "  " + ChangeVariables [Number_ListView, 3]);
		return true;	
	}

	public bool ShowItem1 () { // Показать выделенную колонку или ряд если за пределами прорисовки ************		
		if (ListViewSelected == Number_ListView) { // Если выделенный ListView
			ShowItem2 ();
		}
		return true;
	}

	public bool ShowItem2 () { // Показать выделенную колонку или ряд если за пределами прорисовки ************		
		if (tColumnRect [ListViewSelected, tNumOfColumn [ListViewSelected], 0].x < scrollPosition [ListViewSelected].x) // Если выделенная колонка (слева) за пределами прорисовки
			scrollPosition [ListViewSelected].x = tColumnRect [ListViewSelected, tNumOfColumn [ListViewSelected], 0].x - 1f;
		else // Если выделенная колонка (справа) за пределами прорисовки
			if (tColumnRect [ListViewSelected, tNumOfColumn [ListViewSelected], 0].xMax > (scrollPosition [ListViewSelected].x + Rect_Scroll [ListViewSelected, 2].width))
				scrollPosition [ListViewSelected].x = tColumnRect [ListViewSelected, tNumOfColumn [ListViewSelected], 0].xMax - Rect_Scroll [ListViewSelected, 2].width + 1f;

		if (tItemRect [ListViewSelected, tNumOfItem [ListViewSelected], 0].y < scrollPosition [ListViewSelected].y + tColumnRect [ListViewSelected, 0, 0].height) // Если выделенная колонка (сверху) за пределами прорисовки
			scrollPosition [ListViewSelected].y = tItemRect [ListViewSelected, tNumOfItem [ListViewSelected], 0].y - tColumnRect [ListViewSelected, 0, 0].height - 1f;
		else // Если выделенная колонка (снизу) за пределами прорисовки
			if (tItemRect [ListViewSelected, tNumOfItem [ListViewSelected], 0].yMax > (scrollPosition [ListViewSelected].y + Rect_Scroll [ListViewSelected, 2].height + tColumnRect [ListViewSelected, 0, 0].height))
				scrollPosition [ListViewSelected].y = tItemRect [ListViewSelected, tNumOfItem [ListViewSelected], 0].yMax - Rect_Scroll [ListViewSelected, 2].height - tColumnRect [ListViewSelected, 0, 0].height + 1f;		
		return true;
	}

	public bool Save_EditInField(int LVSelected_1,int tNColumn, int tNItems) // Сохранить свойства текущей таблицы "ListViewSelected"
	{				
		// Если текст был изменен
		if (((EditInField [LVSelected_1]) |
		    (EditInColumn [LVSelected_1]) |
		    (CMchanged [LVSelected_1] == 0))) {
			othertext1 = true;
			if (CMchanged [LVSelected_1] == 0) {
				if ((EditInField [LVSelected_1]) &
				    (ChangingText [LVSelected_1] == tNameOfItems [LVSelected_1, tNColumn, tNItems])) {
					// Текст в ячейке не изменен
					othertext1 = false;
				} else if ((EditInColumn [LVSelected_1]) &
				           (ChangingText [LVSelected_1] == tNameOfColumns [LVSelected_1, tNColumn])) {
					// Текст в колонке не изменен
					othertext1 = false;
				} 
			}

			if (othertext1 == true) { // Если текст был изменен
				//print (Copy_NumOfChange + "  " + LVSelected_1 + "  " + tNColumn + "  " + tNItems);
				// Сохранить до изменения |||||||||||||||||||||||||||||||||||||||
				Copy_CountOfChanges = Copy_CountOfChanges + 1; // Общее количество изменений
				Copy_CountOfChangesF = Copy_CountOfChanges; // Для возвращения вперед

				selStrings [4] = Copy_NumOfChange + " Undo ";

				SaveArrayOfText (LVSelected_1, tNColumn, tNItems); // Сохранить текстовый массив

				if (CMchanged [LVSelected_1] == 1) {
					Copy_tNameOfItems [Copy_NumOfChange, tNColumn, tNItems] = ChangingText [LVSelected_1]; // Не измененнный текст
				} else if (CMchanged [LVSelected_1] == 2) {
					Copy_tNameOfColumns [Copy_NumOfChange, tNColumn] = ChangingText [LVSelected_1]; // Не измененнный текст
				} 
				CMchanged [LVSelected_1] = 0;		

				Copy_NumOfChange = Copy_NumOfChange + 1; // Порядковый номер последнего изменения
				if (Copy_NumOfChange >= Copy_MaximumOfChanges)
					Copy_NumOfChange = 0;
				//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||			
			} else {
				Copy_CountOfChanges = Copy_CountOfChanges - 1; // Общее количество изменений
				Copy_CountOfChangesF = Copy_CountOfChanges; // Для возвращения вперед
				Copy_NumOfChange = Copy_NumOfChange - 1; // Порядковый номер последнего изменения
				if (Copy_NumOfChange < 0)
					Copy_NumOfChange = Copy_MaximumOfChanges - 1;
			}
		}
		return true;	
	}

	public bool SaveArrayOfText (int LVSelected_1,int tNColumn, int tNItems) // Сохранить текстовый массив
	{
		Copy_Count_ListView [Copy_NumOfChange] = Count_ListView;
		Copy_MaximumOfColumns [Copy_NumOfChange] = MaxColumnCount;
		Copy_MaximumOfItems [Copy_NumOfChange] = MaxItemCount;
		Copy_ListViewSelected [Copy_NumOfChange] = LVSelected_1;
		// Поменять размерность массивов если отличаются от предыдущих
		if ((Copy_tNameOfItems.GetLength (2) < tItemProperty [LVSelected_1, 0]) |
			(Copy_tNameOfItems.GetLength (1) < tColumnProperty [LVSelected_1, 0])) {
			Copy_ArrayChanged = 1; // 1-Изменена размерность массивов

			if (Copy_MaximumOfItems [Copy_NumOfChange] < tItemProperty [LVSelected_1, 0])
				Copy_MaximumOfItems [Copy_NumOfChange] = Mathf.FloorToInt (tItemProperty [LVSelected_1, 0]);

			if (Copy_MaximumOfColumns [Copy_NumOfChange] < tColumnProperty [LVSelected_1, 0])
				Copy_MaximumOfColumns [Copy_NumOfChange] = Mathf.FloorToInt (tColumnProperty [LVSelected_1, 0]);


			WriteArrays_Copy (); // Сохранить массивы для перезаписи после изменения размера


			Copy_cStartSizes = (float[,,])ResizeArray (Copy_cStartSizes, new int[] {				
				Copy_MaximumOfChanges, Copy_MaximumOfColumns [Copy_NumOfChange],2}); // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
			Copy_iStartSizes = (float[,,])ResizeArray (Copy_iStartSizes, new int[] {				
				Copy_MaximumOfChanges, Copy_MaximumOfItems [Copy_NumOfChange],1}); // Указанные размеры рядов (0-высота ряда)
			Copy_tColumnRect = (Rect[,,])ResizeArray (Copy_tColumnRect, new int[] {				
				Copy_MaximumOfChanges, Copy_MaximumOfColumns [Copy_NumOfChange],3}); // 0-позиция колонки, 1-позиция кнопки X, 2-позиция текста в колонке
			Copy_tItemRect = (Rect[,,])ResizeArray (Copy_tItemRect, new int[] {				
				Copy_MaximumOfChanges, Copy_MaximumOfItems [Copy_NumOfChange],2}); // 0-позиция ряда, 1-позиция кнопки Y


			Copy_tNameOfColumns = (string[,])ResizeArray (Copy_tNameOfColumns, new int[] {				
				Copy_MaximumOfChanges,									
				Copy_MaximumOfColumns [Copy_NumOfChange]
			});	

			Copy_tNameOfItems = (string[,,])ResizeArray (Copy_tNameOfItems, new int[] {
				Copy_MaximumOfChanges,									
				Copy_MaximumOfColumns [Copy_NumOfChange]
				, Copy_MaximumOfItems [Copy_NumOfChange]
			});	


			ReadArrays_Copy (); // После перезаписи вернуть значения массивов на свои места
		}			

		Copy_tColumnProperty [Copy_NumOfChange, 0] = tColumnProperty [LVSelected_1, 0];
		Copy_tColumnProperty [Copy_NumOfChange, 1] = tColumnProperty [LVSelected_1, 1];
		Copy_tNumOfColumn [Copy_NumOfChange] = tNColumn;
		Copy_tItemProperty [Copy_NumOfChange, 0] = tItemProperty [LVSelected_1, 0];
		Copy_tItemProperty [Copy_NumOfChange, 1] = tItemProperty [LVSelected_1, 1];
		Copy_tItemProperty [Copy_NumOfChange, 2] = tItemProperty [LVSelected_1, 2];
		Copy_tNumOfItem [Copy_NumOfChange] = tNItems;

		for (int i = 0; i < tColumnProperty [LVSelected_1, 0]; i++) {
			Copy_cStartSizes[Copy_NumOfChange,i,0] = cStartSizes[LVSelected_1,i,0];
			Copy_cStartSizes[Copy_NumOfChange,i,1] = cStartSizes[LVSelected_1,i,1];
			Copy_tColumnRect[Copy_NumOfChange,i,0] = tColumnRect[LVSelected_1,i,0]; 
			Copy_tColumnRect[Copy_NumOfChange,i,1] = tColumnRect[LVSelected_1,i,1]; 
			Copy_tColumnRect[Copy_NumOfChange,i,2] = tColumnRect[LVSelected_1,i,2]; 

			Copy_tNameOfColumns [Copy_NumOfChange, i] = tNameOfColumns [LVSelected_1, i];				
		}

		for (int i = 0; i < tItemProperty [LVSelected_1, 0]; i++) {
			Copy_iStartSizes [Copy_NumOfChange, i, 0] = iStartSizes [LVSelected_1, i, 0];
			Copy_tItemRect [Copy_NumOfChange, i, 0] = tItemRect [LVSelected_1, i, 0]; 
			Copy_tItemRect [Copy_NumOfChange, i, 1] = tItemRect [LVSelected_1, i, 1]; 
		}

		for (int i = 0; i < tColumnProperty [LVSelected_1, 0]; i++) {
			for (int j = 0; j < tItemProperty [LVSelected_1, 0]; j++) {
				Copy_tNameOfItems [Copy_NumOfChange, i, j] = tNameOfItems [LVSelected_1, i, j];				
			}
		}			
		return true;	
	}


	public bool ContextMenu_PreAction(int selInt, int LVSelected_1,int tNColumn, int tNItems) {
		
		if (selInt == 0) { // Вырезать
			Save_EditInField (LVSelected_1, tNColumn, tNItems); // Сохранить свойства текущей таблицы "LVSelected_1"
			CMbutton [LVSelected_1] = 0;
			ContextMenu_Button (0,LVSelected_1, tNColumn, tNItems); // Действие контекстного меню
			Save_EditInField (LVSelected_1, tNColumn, tNItems); // Сохранить свойства текущей таблицы "LVSelected_1"
		} else if (selInt == 1) { // Копировать	
			CMbutton [LVSelected_1] = 1;
			ContextMenu_Button (1,LVSelected_1,tNColumn, tNItems);	
		} else if (selInt == 2) { // Вставить
			Save_EditInField (LVSelected_1, tNColumn, tNItems); // Сохранить свойства текущей таблицы "LVSelected_1"
			CMbutton [LVSelected_1] = 2;
			ContextMenu_Button (2,LVSelected_1, tNColumn, tNItems);	
			Save_EditInField (LVSelected_1, tNColumn, tNItems); // Сохранить свойства текущей таблицы "LVSelected_1"
		} else if (selInt == 3) { // Поменять текст ячейки с буфером обмена
			Save_EditInField (LVSelected_1, tNColumn, tNItems); // Сохранить свойства текущей таблицы "LVSelected_1"
			CMbutton [LVSelected_1] = 3;
			ContextMenu_Button (3,LVSelected_1, tNColumn, tNItems);	
			Save_EditInField (LVSelected_1, tNColumn, tNItems); // Сохранить свойства текущей таблицы "LVSelected_1"
		} else if (selInt == 4) { // Отменить изменения
			EditFieldToSimple(); // Закрыть все редактируемые поля
				
			CMbutton [LVSelected_1] = 4;
			ContextMenu_Button (4,LVSelected_1, tNColumn, tNItems);	
		} else if (selInt == 5) { // Вернуть изменения
			EditFieldToSimple(); // Закрыть все редактируемые поля

			CMbutton [LVSelected_1] = 5;
			ContextMenu_Button (5,LVSelected_1, tNColumn, tNItems);						
		}
		return true;	
	}

	public bool ContextMenu_Button(int selInt, int LVSelected_1,int tNColumn, int tNItems) { // Действие контекстного меню	
		MouseRightClick = 0; // 1-нажата правая кнопка мыши, 0-кнопка мыши не нажата
		CMrectangle = new Rect (0, 0, 0, 0);
		if (LVSelected_1 > -1) {
			if (selInt == 0) { // Вырезать
				CopyToBuffer (tNameOfItems [LVSelected_1, tNColumn, tNItems]); // Скопировать в буфер обмена

				tNameOfItems [LVSelected_1, tNColumn, tNItems] = "";
			} else if (selInt == 1) { // Копировать
				CopyToBuffer (tNameOfItems [LVSelected_1, tNColumn, tNItems]); // Скопировать в буфер обмена
			} else if (selInt == 2) { // Вставить
				string s2 = "|"+LVSelected_1.ToString()+"|"+tNColumn.ToString()+"|"+tNItems.ToString()+"|";
				//tNameOfItems [LVSelected_1, tNColumn, tNItems] = PasteFromBuffer (); // Вставить из буфера обмена
				PasteFromBuffer (s2); // Вставить из буфера обмена
			} else if (selInt == 3) { // Поменять текст ячейки с буфером обмена
				string s = tNameOfItems [LVSelected_1, tNColumn, tNItems];
				string s2 = "+|"+LVSelected_1.ToString()+"|"+tNColumn.ToString()+"|"+tNItems.ToString()+"|";
				//tNameOfItems [LVSelected_1, tNColumn, tNItems] = PasteFromBuffer (); // Вставить из буфера обмена
				PasteFromBuffer (s2); // Вставить из буфера обмена
				//CopyToBuffer (s); // Скопировать в буфер обмена
			} else if (selInt == 4) { // Отменить изменения
				
				if (Copy_CountOfChanges - 1 >= 0) { // Если были внесены изменения								
					if (Copy_CountOfChanges == Copy_CountOfChangesF) { // Если выполнен первый возврат после добавления
						SaveArrayOfText (LVSelected_1, tNColumn, tNItems); // Сохранить текстовый массив
					} 
					// Отменить изменения /////////////////////////////////////////
					Copy_CountOfChanges = Copy_CountOfChanges - 1; // Общее количество изменений
					Copy_NumOfChange = Copy_NumOfChange - 1; // Порядковый номер последнего изменения
					if (Copy_NumOfChange < 0)
						Copy_NumOfChange = Copy_MaximumOfChanges - 1;

					selStrings [4] = Copy_NumOfChange+" Undo ";

					TextFromCopy (); // Восстановить текст из копии

					ShowItem2 (); // Показать выделенную колонку или ряд если за пределами прорисовки ************	
				}
			} else if (selInt == 5) { // Вернуть изменения
				
				if (Copy_CountOfChanges + 1 <= Copy_CountOfChangesF) { // Если были внесены изменения
					// Вернуть изменения ///////////////////////////////////////
					Copy_CountOfChanges = Copy_CountOfChanges + 1; // Общее количество внесенных изменений

					Copy_NumOfChange = Copy_NumOfChange + 1; // Порядковый номер последнего изменения в "RichEdt5"
					if (Copy_NumOfChange >= Copy_MaximumOfChanges)
						Copy_NumOfChange = 0; // Переносим цикл от Copy_NumOfChange к 0

					selStrings [5] = Copy_NumOfChange+" Redo ";

					TextFromCopy (); // Восстановить текст из копии

					ShowItem2 (); // Показать выделенную колонку или ряд если за пределами прорисовки ************	
				}
			}
		}
		return true;
	}

	public bool TextFromCopy () { // Восстановить текст из копии
		Count_ListView = Copy_Count_ListView [Copy_NumOfChange];
		MaxColumnCount = Copy_MaximumOfColumns [Copy_NumOfChange];
		MaxItemCount = Copy_MaximumOfItems [Copy_NumOfChange];

		if (Copy_ArrayChanged == 1) { // Если изменена размерность массивов
			Copy_ArrayChanged = 0; // 1-Изменена размерность массивов

			WriteArrays_CI (); // Сохранить массивы для перезаписи после изменения размера

			cStartSizes = (float[,,])ResizeArray (cStartSizes, new int[] {				
				Count_ListView, MaxColumnCount,2}); // Указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
			iStartSizes = (float[,,])ResizeArray (iStartSizes, new int[] {				
				Count_ListView, MaxItemCount,1}); // Указанные размеры рядов (0-высота ряда)
			tColumnRect = (Rect[,,])ResizeArray (tColumnRect, new int[] {				
				Count_ListView, MaxColumnCount,3}); // 0-позиция колонки, 1-позиция кнопки X, 2-позиция текста в колонке
			tItemRect = (Rect[,,])ResizeArray (tItemRect, new int[] {				
				Count_ListView, MaxItemCount,2}); // 0-позиция ряда, 1-позиция кнопки Y

			tNameOfColumns = (string[,])ResizeArray 
			(tNameOfColumns, new int[] { Count_ListView, MaxColumnCount });

			tNameOfItems = (string[,,])ResizeArray 
			(tNameOfItems, new int[] { Count_ListView, MaxColumnCount, MaxItemCount });

			ReadArrays_CI (); // После перезаписи вернуть значения массивов на свои места
		}
				
		ListViewSelected = Copy_ListViewSelected [Copy_NumOfChange];
		tColumnProperty [ListViewSelected, 0] = 
				Copy_tColumnProperty [Copy_NumOfChange, 0];
		tColumnProperty [ListViewSelected, 1] = 
				Copy_tColumnProperty [Copy_NumOfChange, 1];
		tNumOfColumn [ListViewSelected] = 
				Copy_tNumOfColumn [Copy_NumOfChange];
		tItemProperty [ListViewSelected, 0] = 
				Copy_tItemProperty [Copy_NumOfChange, 0];
		tItemProperty [ListViewSelected, 1] = 
				Copy_tItemProperty [Copy_NumOfChange, 1];
		tItemProperty [ListViewSelected, 2] = 
				Copy_tItemProperty [Copy_NumOfChange, 2];
		tNumOfItem [ListViewSelected] = 
				Copy_tNumOfItem [Copy_NumOfChange];

		for (int i = 0; i < tColumnProperty [ListViewSelected, 0]; i++) {
			cStartSizes[ListViewSelected,i,0] = Copy_cStartSizes[Copy_NumOfChange,i,0];
			cStartSizes[ListViewSelected,i,1] = Copy_cStartSizes[Copy_NumOfChange,i,1];
			tColumnRect[ListViewSelected,i,0] = Copy_tColumnRect[Copy_NumOfChange,i,0]; 
			tColumnRect[ListViewSelected,i,1] = Copy_tColumnRect[Copy_NumOfChange,i,1]; 
			tColumnRect[ListViewSelected,i,2] = Copy_tColumnRect[Copy_NumOfChange,i,2]; 

			tNameOfColumns [ListViewSelected, i] = Copy_tNameOfColumns [Copy_NumOfChange, i];
		}

		for (int i = 0; i < tItemProperty [ListViewSelected, 0]; i++) {
			iStartSizes [ListViewSelected, i, 0] = Copy_iStartSizes [Copy_NumOfChange, i, 0];
			tItemRect [ListViewSelected, i, 0] = Copy_tItemRect [Copy_NumOfChange, i, 0]; 
			tItemRect [ListViewSelected, i, 1] = Copy_tItemRect [Copy_NumOfChange, i, 1]; 
		}

		for (int i = 0; i < tColumnProperty [ListViewSelected, 0]; i++) {
			for (int j = 0; j < tItemProperty [ListViewSelected, 0]; j++) {
				tNameOfItems [ListViewSelected, i, j] = Copy_tNameOfItems [Copy_NumOfChange, i, j];
			}
		}

		ChangeSizes (ListViewSelected); // Поменять размеры таблицы
		return true;
	}


	public bool WriteArrays_CI() { // Сохранить массивы для перезаписи после изменения размера
		tColumnRect_c = new Rect[tNameOfItems.GetLength (0), tNameOfItems.GetLength (1), 3];
		tItemRect_c = new Rect[tNameOfItems.GetLength (0), tNameOfItems.GetLength (2), 2];
		cStartSizes_c = new float[tNameOfItems.GetLength (0), tNameOfItems.GetLength (1), 2];
		iStartSizes_c = new float[tNameOfItems.GetLength (0), tNameOfItems.GetLength (2), 1];
		tNameOfColumns_c = new string[tNameOfItems.GetLength (0), tNameOfItems.GetLength (1)];
		tNameOfItems_c = new string[tNameOfItems.GetLength (0), tNameOfItems.GetLength (1), tNameOfItems.GetLength (2)];

		for (int o = 0; o < tNameOfItems.GetLength (0); o++) {
			for (int i = 0; i < tNameOfItems.GetLength (2); i++) {				
				tItemRect_c [o, i, 0] = tItemRect [o, i, 0];
				tItemRect_c [o, i, 1] = tItemRect [o, i, 1];
				iStartSizes_c [o, i, 0] = iStartSizes [o, i, 0];
			}

			for (int i = 0; i < tNameOfItems.GetLength (1); i++) {
				tNameOfColumns_c [o, i] = tNameOfColumns [o, i];

				for (int j = 0; j < tNameOfItems.GetLength (2); j++) {
					tNameOfItems_c [o, i, j] = tNameOfItems [o, i, j];
				}

				tColumnRect_c [o, i, 0] = tColumnRect [o, i, 0];
				tColumnRect_c [o, i, 1] = tColumnRect [o, i, 1];
				tColumnRect_c [o, i, 2] = tColumnRect [o, i, 2];
				cStartSizes_c [o, i, 0] = cStartSizes [o, i, 0];
				cStartSizes_c [o, i, 1] = cStartSizes [o, i, 1];
			}
		}
		return true;
	}

	public bool ReadArrays_CI() { // После перезаписи вернуть значения массивов на свои места
		for (int o = 0; o < tItemRect_c.GetLength (0); o++) {
			for (int i = 0; i < tItemRect_c.GetLength (1); i++) {				
				tItemRect [o, i, 0] = tItemRect_c [o, i, 0];
				tItemRect [o, i, 1] = tItemRect_c [o, i, 1];
				iStartSizes [o, i, 0] = iStartSizes_c [o, i, 0];
			}

			for (int i = 0; i < tColumnRect_c.GetLength (1); i++) {
				tNameOfColumns [o, i] = tNameOfColumns_c [o, i];

				for (int j = 0; j < tItemRect_c.GetLength (1); j++) {
					tNameOfItems [o, i, j] = tNameOfItems_c [o, i, j];
				}

				tColumnRect [o, i, 0] = tColumnRect_c [o, i, 0];
				tColumnRect [o, i, 1] = tColumnRect_c [o, i, 1];
				tColumnRect [o, i, 2] = tColumnRect_c [o, i, 2];
				cStartSizes [o, i, 0] = cStartSizes_c [o, i, 0];
				cStartSizes [o, i, 1] = cStartSizes_c [o, i, 1];
			}
		}	
		tColumnRect_c = new Rect[0, 0, 0];
		tItemRect_c = new Rect[0, 0, 0];
		cStartSizes_c = new float[0, 0, 0];
		iStartSizes_c = new float[0, 0, 0];
		tNameOfColumns_c = new string[0, 0];
		tNameOfItems_c = new string[0, 0, 0];
		return true;
	}

	public bool WriteArrays_Copy() { // Сохранить массивы для перезаписи после изменения размера
		tColumnRect_c = new Rect[Copy_tNameOfItems.GetLength (0), Copy_tNameOfItems.GetLength (1), 3];
		tItemRect_c = new Rect[Copy_tNameOfItems.GetLength (0), Copy_tNameOfItems.GetLength (2), 2];
		cStartSizes_c = new float[Copy_tNameOfItems.GetLength (0), Copy_tNameOfItems.GetLength (1), 2];
		iStartSizes_c = new float[Copy_tNameOfItems.GetLength (0), Copy_tNameOfItems.GetLength (2), 1];
		tNameOfColumns_c = new string[Copy_tNameOfItems.GetLength (0), Copy_tNameOfItems.GetLength (1)];
		tNameOfItems_c = new string[Copy_tNameOfItems.GetLength (0), Copy_tNameOfItems.GetLength (1), Copy_tNameOfItems.GetLength (2)];

		for (int o = 0; o < Copy_tNameOfItems.GetLength (0); o++) {
			for (int i = 0; i < Copy_tNameOfItems.GetLength (2); i++) {				
				tItemRect_c [o, i, 0] = Copy_tItemRect [o, i, 0];
				tItemRect_c [o, i, 1] = Copy_tItemRect [o, i, 1];
				iStartSizes_c [o, i, 0] = Copy_iStartSizes [o, i, 0];
			}

			for (int i = 0; i < Copy_tNameOfItems.GetLength (1); i++) {
				tNameOfColumns_c [o, i] = Copy_tNameOfColumns [o, i];

				for (int j = 0; j < Copy_tNameOfItems.GetLength (2); j++) {
					tNameOfItems_c [o, i, j] = Copy_tNameOfItems [o, i, j];
				}

				tColumnRect_c [o, i, 0] = Copy_tColumnRect [o, i, 0];
				tColumnRect_c [o, i, 1] = Copy_tColumnRect [o, i, 1];
				tColumnRect_c [o, i, 2] = Copy_tColumnRect [o, i, 2];
				cStartSizes_c [o, i, 0] = Copy_cStartSizes [o, i, 0];
				cStartSizes_c [o, i, 1] = Copy_cStartSizes [o, i, 1];
			}
		}
		return true;
	}

	public bool ReadArrays_Copy() { // После перезаписи вернуть значения массивов на свои места
		for (int o = 0; o < tItemRect_c.GetLength (0); o++) {
			for (int i = 0; i < tItemRect_c.GetLength (1); i++) {				
				Copy_tItemRect [o, i, 0] = tItemRect_c [o, i, 0];
				Copy_tItemRect [o, i, 1] = tItemRect_c [o, i, 1];
				Copy_iStartSizes [o, i, 0] = iStartSizes_c [o, i, 0];
			}

			for (int i = 0; i < tColumnRect_c.GetLength (1); i++) {
				Copy_tNameOfColumns [o, i] = tNameOfColumns_c [o, i];

				for (int j = 0; j < tItemRect_c.GetLength (1); j++) {
					Copy_tNameOfItems [o, i, j] = tNameOfItems_c [o, i, j];
				}

				Copy_tColumnRect [o, i, 0] = tColumnRect_c [o, i, 0];
				Copy_tColumnRect [o, i, 1] = tColumnRect_c [o, i, 1];
				Copy_tColumnRect [o, i, 2] = tColumnRect_c [o, i, 2];
				Copy_cStartSizes [o, i, 0] = cStartSizes_c [o, i, 0];
				Copy_cStartSizes [o, i, 1] = cStartSizes_c [o, i, 1];
			}
		}	
		tColumnRect_c = new Rect[0, 0, 0];
		tItemRect_c = new Rect[0, 0, 0];
		cStartSizes_c = new float[0, 0, 0];
		iStartSizes_c = new float[0, 0, 0];
		tNameOfColumns_c = new string[0, 0];
		tNameOfItems_c = new string[0, 0, 0];
		return true;
	}

	public bool SaveChanges1() { 
		if ((Show_Hide [9] == false) & (EditInColumn [Number_ListView] == true)) { // Вернуть не измененный текст колонки
			tNameOfColumns [Number_ListView, tNumOfColumn [Number_ListView]] = ChangingText [Number_ListView];
		} else if ((Show_Hide [5] == false) & (EditInField [Number_ListView] == true)) { // Вернуть не измененный текст ячейки
			tNameOfItems [Number_ListView, tNumOfColumn [Number_ListView], tNumOfItem [Number_ListView]] = ChangingText [Number_ListView];
		} else if ((EditInColumn [Number_ListView] == true) | 
			(EditInField [Number_ListView] == true)) {	
			Save_EditInField (ListViewSelected, tNumOfColumn [ListViewSelected], 
				tNumOfItem [ListViewSelected]); // Сохранить свойства текущей таблицы "ListViewSelected"
		}
		return true;
	}

	public bool SaveChanges1_AllTables() { // Сохранить текст во всех таблицах (Для возврата изменений "Undo", "Redo")
		int LV_2, CMch_2;
		for (LV_2 = 0; LV_2 <= Count_ListView - 1; LV_2++) {
			{
				CMch_2 = CMchanged [LV_2];
				CMchanged [LV_2] = 0;
				Save_EditInField (LV_2, tNumOfColumn [LV_2], tNumOfItem [LV_2]); // Сохранить свойства текущей таблицы "ListViewSelected"
				CMchanged [LV_2] = CMch_2;
			}				
		}
		return true;
	}

	public bool CopyToBuffer(string s) { // Скопировать в буфер обмена		
		//TextEditor te = new TextEditor ();
		//te.text = s;
		//te.SelectAll ();
		//te.Copy ();
		//GUIUtility.systemCopyBuffer = s;

		#if UNITY_WEBGL
		copyStringToClipboard(s); // Скопировать в буфер обмена
		#else
		Debug.LogError("Not implemented in this platform");
		#endif

		return true;
	}

	public string PasteFromBuffer(string WhereToPaste) { // Вставить из буфера обмена		
		//TextEditor te = new TextEditor ();
		//te.Paste ();
		//te.SelectAll ();
		//return te.text;	
		//return GUIUtility.systemCopyBuffer;

		#if UNITY_WEBGL
		pasteStringFromClipboard(gameObject.name, "GetPastedText@"+WhereToPaste); // Вставить из буфера обмена		
		#else
		Debug.LogError("Not implemented in this platform");
		#endif

		return "";
	}

	public void GetPastedText(string newpastedtext) // Вставить из буфера обмена (Функция вызывается из JavaScript)	
	{		
		// Достать значения из строки
		int Pp1 = newpastedtext.IndexOf ("%")+1;
		int Pp2 = newpastedtext.Length;
		int Pp3 = Pp1;

		string PastedData = newpastedtext.Substring (Pp1, Pp2 - Pp1); // Вставленный текст
		string dataUrlCopy = ""; 

		//print (PastedData+"|456+++");

		Pp1 = newpastedtext.IndexOf ("|");
		int[] nn1 = new int[3];

		for (var y = 0; y < 3; y++) {							

			if (Pp1 > -1) {		
				Pp2 = newpastedtext.IndexOf ("|", Pp1 + 2);

				if (Pp2 == -1) {	
					Pp2 = newpastedtext.Length;
				}

				dataUrlCopy = newpastedtext.Substring (Pp1+1, Pp2 - Pp1 - 1);
				int.TryParse(dataUrlCopy, out nn1[y]); // Числа для текстового массива

				//print (dataUrlCopy+"\n"+nn1[y]);				
				Pp1 = Pp2;
			}						
		}

		int i = 0;
		int NewPos1 = 0;
		int NewPos2 = 0;
		if (CopyedPos1 [0] >= CopyedPos1 [1]) {
			i = 1;		
		}

		NewPos1 = CopyedPos1 [i]+PastedData.Length; // Новая позиция курсора
		NewPos2 = CopyedPos1 [Mathf.Abs(i*2-1)]; // Новая выделенная позиция курсора


		int Pp4 = newpastedtext.IndexOf ("+");
		dataUrlCopy = tNameOfItems [nn1[0], nn1[1], nn1[2]];

		if ((Pp4 > -1) & (Pp4 <= Pp3)) { // Если нужно поменять местами буфер обмена и скопированный текст
			CopyToBuffer (dataUrlCopy); // Скопировать в буфер обмена
			tNameOfItems [nn1 [0], nn1 [1], nn1 [2]] = PastedData; // Вставить из буфера обмена
		} else  if (EditInField [nn1 [0]]) { // Если можно редактировать ячейку
			Pp4 = newpastedtext.IndexOf ("=");
			if ((Pp4 > -1) & (Pp4 <= Pp3)) { // Если нужно вставить текст из буфера обмена
				// Заменить часть строки

				if (CopyedPos1 [0] > CopyedText1.Length) {
					CopyedPos1 [0] = CopyedText1.Length;
				}

				if (CopyedPos1 [1] > CopyedText1.Length) {
					CopyedPos1 [1] = CopyedText1.Length;
				}

				string LeftText1 = ""; // Левая часть текста (без выделенной части)
				if (CopyedText1.Length > 0) {
					if (CopyedPos1[0] < CopyedPos1[1]) {
						LeftText1 = CopyedText1.Substring (0, CopyedPos1[0]); // Левая часть текста (без выделенной части)
					} else {
						LeftText1 = CopyedText1.Substring (0, CopyedPos1[1]); // Левая часть текста (без выделенной части)
					}
				}

				string RightText1 = ""; // Правая часть текста (без выделенной части)
				if (CopyedText1.Length > 0) {
					if (CopyedPos1[0] < CopyedPos1[1]) {
						RightText1 = CopyedText1.Substring (CopyedPos1[1], CopyedText1.Length - CopyedPos1[1]); // Правая часть текста (без выделенной части)
					} else {
						RightText1 = CopyedText1.Substring (CopyedPos1[0], CopyedText1.Length - CopyedPos1[0]); // Правая часть текста (без выделенной части)
					}
				}

				//print (LeftText1+"\n"+RightText1);

				tNameOfItems [nn1 [0], nn1 [1], nn1 [2]] = LeftText1 + PastedData + RightText1;

				TextEditor te = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);

				if (te != null) {
					te.cursorIndex = NewPos1; // Переместить курсор на "NewPos1" символ
					te.selectIndex = NewPos2; // Переместить выделенный курсор на "NewPos2" символ
				}	
				///////////////////////////////////////////////////			
			}
		} else if (EditInColumn [nn1 [0]]) { // Если можно редактировать колонку
			Pp4 = newpastedtext.IndexOf ("=");
			if ((Pp4 > -1) & (Pp4 <= Pp3)) { // Если нужно вставить текст из буфера обмена
				// Заменить часть строки

				if (CopyedPos1 [0] > CopyedText1.Length) {
					CopyedPos1 [0] = CopyedText1.Length;
				}

				if (CopyedPos1 [1] > CopyedText1.Length) {
					CopyedPos1 [1] = CopyedText1.Length;
				}

				string LeftText1 = ""; // Левая часть текста (без выделенной части)
				if (CopyedText1.Length > 0) {
					if (CopyedPos1[0] < CopyedPos1[1]) {
						LeftText1 = CopyedText1.Substring (0, CopyedPos1[0]); // Левая часть текста (без выделенной части)
					} else {
						LeftText1 = CopyedText1.Substring (0, CopyedPos1[1]); // Левая часть текста (без выделенной части)
					}
				}

				string RightText1 = ""; // Правая часть текста (без выделенной части)
				if (CopyedText1.Length > 0) {
					if (CopyedPos1[0] < CopyedPos1[1]) {
						RightText1 = CopyedText1.Substring (CopyedPos1[1], CopyedText1.Length - CopyedPos1[1]); // Правая часть текста (без выделенной части)
					} else {
						RightText1 = CopyedText1.Substring (CopyedPos1[0], CopyedText1.Length - CopyedPos1[0]); // Правая часть текста (без выделенной части)
					}
				}

				//print (LeftText1+"\n"+RightText1);

				tNameOfColumns [nn1 [0], nn1 [1]] = LeftText1 + PastedData + RightText1;

				TextEditor te = (TextEditor)GUIUtility.GetStateObject(typeof(TextEditor), GUIUtility.keyboardControl);

				if (te != null) {
					te.cursorIndex = NewPos1; // Переместить курсор на "NewPos1" символ
					te.selectIndex = NewPos2; // Переместить выделенный курсор на "NewPos2" символ
				}	
				///////////////////////////////////////////////////			
			}
		} else { // Если ячейка и колонка не редактируются
			tNameOfItems [nn1 [0], nn1 [1], nn1 [2]] = PastedData; // Вставить из буфера обмена		
		}			
		/////////////////////////////////////////////////// 
	}

	private static Array ResizeArray(Array arr, int[] newSizes)
	{
		if (newSizes.Length != arr.Rank)
			throw new ArgumentException("arr must have the same number of dimensions " +
				"as there are elements in newSizes", "newSizes"); 

		var temp = Array.CreateInstance(arr.GetType().GetElementType(), newSizes);
		int length = arr.Length <= temp.Length ? arr.Length : temp.Length;
		Array.ConstrainedCopy(arr, 0, temp, 0, length);
		return temp;
	} 




	// Сохранение и загрузка в WebGL (на сервер) ///////////////////////////////////////
	/*
	[DllImport("__Internal")]
	private static extern void SyncFiles();

	[DllImport("__Internal")]
	private static extern void WindowAlert(string message);

	public bool SaveDataWebGl1 () { // Сохранить информацию WebGl
		int CountToSave = 9;
		string [] filenameS = new string[CountToSave];
		string [] dataPath = new string[CountToSave];
		filenameS[0] = "tColumnRect.txt";
		filenameS[1] = "tItemRect.txt";
		filenameS[2] = "tColumnProperty.txt";
		filenameS[3] = "tItemProperty.txt";
		filenameS[4] = "tNameOfColumns.txt";
		filenameS[5] = "tNameOfItems.txt";
		filenameS[6] = "MainRect_float.txt";
		filenameS[7] = "cStartSizes.txt";
		filenameS[8] = "iStartSizes.txt";

		try {
			// Переместить не сериализуемый "Rect" в формат "float" ///////////
			float [,,,] saveColumnRect  = new float[Count_ListView,MaxColumnCount,tColumnRect.GetLength (2),4]; // 0-позиция колонки, 1-позиция кнопки X, 2-позиция текста в колонке			
			float [,,,] saveItemRect  = new float[Count_ListView,MaxItemCount,tItemRect.GetLength (2),4]; // 0-позиция ряда, 1-позиция кнопки Y

			for (int i1 = 0; i1 < Count_ListView; i1++) {
				for (int i2 = 0; i2 < MaxColumnCount; i2++) {
					for (int i3 = 0; i3 < tColumnRect.GetLength (2); i3++) {
						saveColumnRect[i1,i2,i3,0] = tColumnRect[i1,i2,i3].x;
						saveColumnRect[i1,i2,i3,1] = tColumnRect[i1,i2,i3].y;
						saveColumnRect[i1,i2,i3,2] = tColumnRect[i1,i2,i3].width;
						saveColumnRect[i1,i2,i3,3] = tColumnRect[i1,i2,i3].height;
					}				
				}

				for (int i2 = 0; i2 < MaxItemCount; i2++) {
					for (int i3 = 0; i3 < tItemRect.GetLength (2); i3++) {
						saveItemRect[i1,i2,i3,0] = tItemRect[i1,i2,i3].x;
						saveItemRect[i1,i2,i3,1] = tItemRect[i1,i2,i3].y;
						saveItemRect[i1,i2,i3,2] = tItemRect[i1,i2,i3].width;
						saveItemRect[i1,i2,i3,3] = tItemRect[i1,i2,i3].height;
					}				
				}
			}
			///////////////////////////////////////////////////////////////////


			for (int i = 0; i < CountToSave; i++) {
				dataPath [i] = string.Format ("{0}/" + SaveTables [0] + filenameS [i], Application.persistentDataPath);
				BinaryFormatter binaryFormatter;
				FileStream fileStream;
				binaryFormatter = new BinaryFormatter ();

				if (File.Exists (dataPath [i])) {
					File.WriteAllText (dataPath [i], string.Empty);
					fileStream = File.Open (dataPath [i], FileMode.Open);
				} else {
					fileStream = File.Create (dataPath [i]);
				}

				if (i==0) { // Сохранить позиции колонок
					binaryFormatter.Serialize (fileStream, saveColumnRect);
				} else if (i==1) { // Сохранить позиции ячеек
					binaryFormatter.Serialize (fileStream, saveItemRect);
				} else if (i==2) { // Сохранить свойства колонок
					binaryFormatter.Serialize (fileStream, tColumnProperty);
				} else if (i==3) { // Сохранить свойства ячеек
					binaryFormatter.Serialize (fileStream, tItemProperty);
				} else if (i==4) { // Сохранить текст колонок
					binaryFormatter.Serialize (fileStream, tNameOfColumns);
				} else if (i==5) { // Сохранить текст ячеек
			    	binaryFormatter.Serialize (fileStream, tNameOfItems);				
				} else if (i==6) { // Сохранить (размеры скроллов) 0-X, 1-Y, 2-Width, 3-Height скролла (границ) компонента ListView
					binaryFormatter.Serialize (fileStream, MainRect_float);				
				} else if (i==7) { // Сохранить указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
					binaryFormatter.Serialize (fileStream, cStartSizes);				
				} else if (i==8) { // Сохранить указанные размеры рядов (0-высота ряда)
					binaryFormatter.Serialize (fileStream, iStartSizes);				
				}

				fileStream.Close ();

				if (Application.platform == RuntimePlatform.WebGLPlayer) {
					SyncFiles ();
				}
				print ("Saved: "+i);			
			}
		} catch (Exception e) {
			PlatformSafeMessage ("Failed to Save: " + e.Message);

		}		
		return true;
	}		

	public bool LoadDataWebGl1 () { // Загрузить информацию WebGl
		// Сохранить таблицы перед загрузкой
		SaveChanges1_AllTables(); // Сохранить текст во всех таблицах (Для возврата изменений "Undo", "Redo")

		int CountToLoad = 9;
		string [] filenameO = new string[CountToLoad];
		string [] dataPath = new string[CountToLoad];
		filenameO[0] = "tColumnRect.txt";
		filenameO[1] = "tItemRect.txt";
		filenameO[2] = "tColumnProperty.txt";
		filenameO[3] = "tItemProperty.txt";
		filenameO[4] = "tNameOfColumns.txt";
		filenameO[5] = "tNameOfItems.txt";
		filenameO[6] = "MainRect_float.txt";
		filenameO[7] = "cStartSizes.txt";
		filenameO[8] = "iStartSizes.txt";

		try {
			float[,,,] saveColumnRect = new float[0,0,0,0];
			float[,,,] saveItemRect = new float[0,0,0,0];

			for (int i = 0; i < CountToLoad; i++) {
				dataPath [i] = string.Format ("{0}/" + LoadTables [0] + filenameO [i], Application.persistentDataPath);
				if (File.Exists (dataPath[i])) {
					BinaryFormatter binaryFormatter = new BinaryFormatter ();
					FileStream fileStream = File.Open (dataPath [i], FileMode.Open);

					if (i==0) { // Загрузить позиции колонок
						saveColumnRect = (float [,,,])binaryFormatter.Deserialize (fileStream);
					} else if (i==1) { // Загрузить позиции ячеек
						saveItemRect = (float [,,,])binaryFormatter.Deserialize (fileStream);
					} else if (i==2) { // Загрузить свойства колонок
						tColumnProperty = (float[,])binaryFormatter.Deserialize (fileStream);
					} else if (i==3) { // Загрузить свойства ячеек
						tItemProperty = (float[,])binaryFormatter.Deserialize (fileStream);
					} else if (i==4) { // Загрузить текст колонок
						tNameOfColumns = (string[,])binaryFormatter.Deserialize (fileStream);
					} else if (i==5) { // Загрузить текст ячеек							
			    		tNameOfItems = (string[,,])binaryFormatter.Deserialize (fileStream);
					} else if (i==6) { // Загрузить (размеры скроллов) 0-X, 1-Y, 2-Width, 3-Height скролла (границ) компонента ListView
						MainRect_float = (float[,])binaryFormatter.Deserialize (fileStream);		
					} else if (i==7) { // Сохранить указанные размеры колонок (0-ширина колонок, 1-высота колонок "для всех одинаковая")
						cStartSizes = (float[,,])binaryFormatter.Deserialize (fileStream);					
					} else if (i==8) { // Сохранить указанные размеры рядов (0-высота ряда)
						iStartSizes = (float[,,])binaryFormatter.Deserialize (fileStream);					
					}

					fileStream.Close ();					
				}			
				print ("Loaded: "+i);					
			}

			// Переместить "float" в формат "Rect" ///////////
			Count_ListView = tNameOfItems.GetLength (0); // Количество таблиц
			MaxColumnCount = saveColumnRect.GetLength (1); // Макимальное количество колонок
			MaxItemCount = saveItemRect.GetLength (1); // Максимальное количество ячеек

			tColumnRect = new Rect[Count_ListView,MaxColumnCount,saveColumnRect.GetLength (2)];
			tItemRect = new Rect[Count_ListView,MaxItemCount,saveItemRect.GetLength (2)];

			for (int i1 = 0; i1 < Count_ListView; i1++) {
				for (int i2 = 0; i2 < MaxColumnCount; i2++) {
					for (int i3 = 0; i3 < saveColumnRect.GetLength (2); i3++) {
						tColumnRect [i1, i2, i3] = new Rect (saveColumnRect[i1,i2,i3,0], 
							saveColumnRect[i1,i2,i3,1], saveColumnRect[i1,i2,i3,2],
							saveColumnRect[i1,i2,i3,3]);
					}				
				}

				for (int i2 = 0; i2 < MaxItemCount; i2++) {
					for (int i3 = 0; i3 < saveItemRect.GetLength (2); i3++) {
						tItemRect [i1, i2, i3] = new Rect (saveItemRect[i1,i2,i3,0], 
							saveItemRect[i1,i2,i3,1], saveItemRect[i1,i2,i3,2],
							saveItemRect[i1,i2,i3,3]);
					}				
				}
			}
			///////////////////////////////////////////////////////////////////

			for (int Number_ListView_1 = 0; Number_ListView_1 <= Count_ListView - 1; Number_ListView_1++) {
				Rect_Scroll [Number_ListView_1, 1] = new Rect (MainRect_float [Number_ListView_1, 0],
					MainRect_float [Number_ListView_1, 1], MainRect_float [Number_ListView_1, 2], 
					MainRect_float [Number_ListView_1, 3]); // Ширина и высота компонента ListView с ползунками			

				ChangeSizes (Number_ListView_1); // Поменять размеры таблицы
			}

			// Сохранить таблицы после загрузки
			SaveChanges1_AllTables(); // Сохранить текст во всех таблицах (Для возврата изменений "Undo", "Redo")

		} catch (Exception e) {
			PlatformSafeMessage ("Failed to Load: " + e.Message);
		}					
		return true;        
	}

	private static void PlatformSafeMessage(string message) // Сообщение об ошибке
	{
		if (Application.platform == RuntimePlatform.WebGLPlayer)
		{
			WindowAlert(message);            
		}
		else
		{
			Debug.Log(message);
		}
	}	
		
	//////////////////////////////////////////////////////////////////////// */

	// Сохранение и загрузка в WebGL ///////////////////////////////////////

	[Serializable]
	public class SeveralVariables // Все значения в одной переменной
	{
		public float [,,,] saveColumnRect1_a;
		public float [,,,] saveItemRect1_a;
		public float[,] tColumnProperty1_a;
		public float[,] tItemProperty1_a;
		public string[,] tNameOfColumns1_a;
		public string[,,] tNameOfItems1_a;
		public float[,] MainRect_float1_a;		
		public float[,,] cStartSizes1_a;					
		public float[,,] iStartSizes1_a;	
	}


	public bool SaveDataWebGl1 () { // Сохранить информацию WebGl

		try {
			// Переместить не сериализуемый "Rect" в формат "float" ///////////
			float [,,,] saveColumnRect  = new float[Count_ListView,MaxColumnCount,tColumnRect.GetLength (2),4]; // 0-позиция колонки, 1-позиция кнопки X, 2-позиция текста в колонке			
			float [,,,] saveItemRect  = new float[Count_ListView,MaxItemCount,tItemRect.GetLength (2),4]; // 0-позиция ряда, 1-позиция кнопки Y

			for (int i1 = 0; i1 < Count_ListView; i1++) {
				for (int i2 = 0; i2 < MaxColumnCount; i2++) {
					for (int i3 = 0; i3 < tColumnRect.GetLength (2); i3++) {
						saveColumnRect[i1,i2,i3,0] = tColumnRect[i1,i2,i3].x;
						saveColumnRect[i1,i2,i3,1] = tColumnRect[i1,i2,i3].y;
						saveColumnRect[i1,i2,i3,2] = tColumnRect[i1,i2,i3].width;
						saveColumnRect[i1,i2,i3,3] = tColumnRect[i1,i2,i3].height;
					}				
				}

				for (int i2 = 0; i2 < MaxItemCount; i2++) {
					for (int i3 = 0; i3 < tItemRect.GetLength (2); i3++) {
						saveItemRect[i1,i2,i3,0] = tItemRect[i1,i2,i3].x;
						saveItemRect[i1,i2,i3,1] = tItemRect[i1,i2,i3].y;
						saveItemRect[i1,i2,i3,2] = tItemRect[i1,i2,i3].width;
						saveItemRect[i1,i2,i3,3] = tItemRect[i1,i2,i3].height;
					}				
				}
			}
			///////////////////////////////////////////////////////////////////

			// Сохранить все значения в одной переменной
			SeveralVariables UltraVarriable = new SeveralVariables();
			UltraVarriable.saveColumnRect1_a = saveColumnRect;
			UltraVarriable.saveItemRect1_a = saveItemRect;
			UltraVarriable.tColumnProperty1_a = tColumnProperty;
			UltraVarriable.tItemProperty1_a = tItemProperty;
			UltraVarriable.tNameOfColumns1_a = tNameOfColumns;
			UltraVarriable.tNameOfItems1_a = tNameOfItems;
			UltraVarriable.MainRect_float1_a = MainRect_float;		
			UltraVarriable.cStartSizes1_a = cStartSizes;					
			UltraVarriable.iStartSizes1_a = iStartSizes;	


			MemoryStream stream1 = SerializeToStream(UltraVarriable); // Сохранить переменную в стрим
    	        	byte[] m_Bytes = stream1.ToArray(); // Перевести информацию из стрима в байты
			string streamDataStr = System.Convert.ToBase64String (m_Bytes); // Перевести байты в текст

			#if UNITY_WEBGL
			SaveFile(streamDataStr,SaveTables [0]+"_ListViewProperties.txt"); // Обратиться к функции JavaScript "SaveFile" чтобы сохранить текст "streamDataStr" в файл
			#else
			Debug.LogError("Not implemented in this platform");
			#endif

			print ("Saved");

		} catch (Exception e) {
			print ("Failed to Save: " + e.Message);
		}		
		return true;
	}				

	public void LoadDataWebGl1(string dataUrl) { // Полученный текст
		// Сохранить таблицы перед загрузкой
		SaveChanges1_AllTables(); // Сохранить текст во всех таблицах (Для возврата изменений "Undo", "Redo")

		int Pp1 = 0;
		int Pp2 = 0;
		string FileName = "";
		Pp1 = dataUrl.IndexOf ("|");
		if (Pp1 > -1) {

		 FileName = dataUrl.Substring (0, Pp1);
		 dataUrl = dataUrl.Substring (Pp1 + 2, dataUrl.Length - (Pp1 + 2));

		 Pp2 = FileName.IndexOf ("_ListViewProperties");

		 if (Pp2 > -1) {
		  try {
			float[,,,] saveColumnRect = new float[0,0,0,0];
			float[,,,] saveItemRect = new float[0,0,0,0];

			byte[] m_Bytes = System.Convert.FromBase64String (dataUrl); // Перевести текст в байты
			MemoryStream stream1 =  new MemoryStream(m_Bytes); // Перевести байты в стрим

			SeveralVariables UltraVarriable = (SeveralVariables)DeserializeFromStream(stream1);

			print ("Loaded");					

			saveColumnRect = UltraVarriable.saveColumnRect1_a;
			saveItemRect = UltraVarriable.saveItemRect1_a;
			tColumnProperty = UltraVarriable.tColumnProperty1_a;
			tItemProperty = UltraVarriable.tItemProperty1_a;
			tNameOfColumns = UltraVarriable.tNameOfColumns1_a;
			tNameOfItems = UltraVarriable.tNameOfItems1_a;
			MainRect_float = UltraVarriable.MainRect_float1_a;		
			cStartSizes = UltraVarriable.cStartSizes1_a;					
			iStartSizes = UltraVarriable.iStartSizes1_a;


			// Переместить "float" в формат "Rect" ///////////
			Count_ListView = tNameOfItems.GetLength (0); // Количество таблиц
			MaxColumnCount = saveColumnRect.GetLength (1); // Макимальное количество колонок
			MaxItemCount = saveItemRect.GetLength (1); // Максимальное количество ячеек

			tColumnRect = new Rect[Count_ListView,MaxColumnCount,saveColumnRect.GetLength (2)];
			tItemRect = new Rect[Count_ListView,MaxItemCount,saveItemRect.GetLength (2)];

			for (int i1 = 0; i1 < Count_ListView; i1++) {
				for (int i2 = 0; i2 < MaxColumnCount; i2++) {
					for (int i3 = 0; i3 < saveColumnRect.GetLength (2); i3++) {
						tColumnRect [i1, i2, i3] = new Rect (saveColumnRect[i1,i2,i3,0], 
							saveColumnRect[i1,i2,i3,1], saveColumnRect[i1,i2,i3,2],
							saveColumnRect[i1,i2,i3,3]);
					}				
				}

				for (int i2 = 0; i2 < MaxItemCount; i2++) {
					for (int i3 = 0; i3 < saveItemRect.GetLength (2); i3++) {
						tItemRect [i1, i2, i3] = new Rect (saveItemRect[i1,i2,i3,0], 
							saveItemRect[i1,i2,i3,1], saveItemRect[i1,i2,i3,2],
							saveItemRect[i1,i2,i3,3]);
					}				
				}
			}
			///////////////////////////////////////////////////////////////////

			for (int Number_ListView_1 = 0; Number_ListView_1 <= Count_ListView - 1; Number_ListView_1++) {
				Rect_Scroll [Number_ListView_1, 1] = new Rect (MainRect_float [Number_ListView_1, 0],
					MainRect_float [Number_ListView_1, 1], MainRect_float [Number_ListView_1, 2], 
					MainRect_float [Number_ListView_1, 3]); // Ширина и высота компонента ListView с ползунками			

				ChangeSizes (Number_ListView_1); // Поменять размеры таблицы
			}

			// Сохранить таблицы после загрузки
			SaveChanges1_AllTables(); // Сохранить текст во всех таблицах (Для возврата изменений "Undo", "Redo")

		  } catch (Exception e) {
			print ("Failed to Load: " + e.Message);
		  }
		 }
		}
	}
		

	public static MemoryStream SerializeToStream(object o)
	{
		MemoryStream stream = new MemoryStream();
		IFormatter formatter = new BinaryFormatter();
		formatter.Serialize(stream, o);
		return stream;
	}

	public static object DeserializeFromStream(MemoryStream stream)
	{
		IFormatter formatter = new BinaryFormatter();
		stream.Seek(0, SeekOrigin.Begin);
		object o = formatter.Deserialize(stream);
		return o;
	}

	//////////////////////////////////////////////////////////////////////

}









// Сохранение и загрузка в WebGL (на сервер) ///////////////////////////////////////

/* По указанному пути создать файл "HandleIO.jslib".
	Assets/Plugins/WebGL/HandleIO.jslib

	Сохранить в этом файле текст:

	var HandleIO = {
		WindowAlert : function(message)
		{
			window.alert(Pointer_stringify(message));
		},
		SyncFiles : function()
		{
			FS.syncfs(false,function (err) {
				// handle callback
			});
		}
	};

	mergeInto(LibraryManager.library, HandleIO);   */

////////////////////////////////////////////////////////////////////////


// или


// Сохранение и загрузка в WebGL ///////////////////////////////////////

/* По указанному пути создать файл "GetImage.jslib".
	Assets/Plugins/WebGL/GetImage.jslib

	Сохранить в этом файле текст:

	var getImage = {
		getImageFromBrowser: function(objectNamePtr, funcNamePtr) {
			window.Javacript_getImageFromBrowser =
				window.Javacript_getImageFromBrowser || {
				busy: false,
				initialized: false,
				rootDisplayStyle: null,  // style to make root element visible
				root_: null,             // root element of form
				ctx_: null,              // canvas for getting image data;
			};
			var g = window.Javacript_getImageFromBrowser;
			if (g.busy) {
				// Don't let multiple requests come in
				return;
			}
			g.busy = true;

			var objectName = Pointer_stringify(objectNamePtr);
			var funcName = Pointer_stringify(funcNamePtr);

			if (!g.initialized) {
				g.initialized = true;
				g.ctx = window.document.createElement("canvas").getContext("2d");

				// Append a form to the page (more self contained than editing the HTML?)
				g.root = window.document.createElement("div");
				g.root.innerHTML = [
					'<style>                                                    ',
					'.getimage {                                                ',
					'    position: absolute;                                    ',
					'    left: 0;                                               ',
					'    top: 0;                                                ',
					'    width: 100%;                                           ',
					'    height: 100%;                                          ',
					'    display: -webkit-flex;                                 ',
					'    display: flex;                                         ',
					'    -webkit-flex-flow: column;                             ',
					'    flex-flow: column;                                     ',
					'    -webkit-justify-content: center;                       ',
					'    -webkit-align-content: center;                         ',
					'    -webkit-align-items: center;                           ',
					'                                                           ',
					'    justify-content: center;                               ',
					'    align-content: center;                                 ',
					'    align-items: center;                                   ',
					'                                                           ',
					'    z-index: 2;                                            ',
					'    color: white;                                          ',
					'    background-color: rgba(0,0,0,0.8);                     ',
					'    font: sans-serif;                                      ',
					'    font-size: x-large;                                    ',
					'}                                                          ',
					'.getimage a,                                               ',
					'.getimage label {                                          ',
					'   font-size: x-large;                                     ',
					'   background-color: #666;                                 ',
					'   border-radius: 0.5em;                                   ',
					'   border: 1px solid black;                                ',
					'   padding: 0.5em;                                         ',
					'   margin: 0.25em;                                         ',
					'   outline: none;                                          ',
					'   display: inline-block;                                  ',
					'}                                                          ',
					'.getimage input {                                          ',
					'    display: none;                                         ',
					'}                                                          ',
					'</style>                                                   ',
					'<div class="getimage">                                     ',
					'    <div>                                                  ',
					'      <label for="photo">click to choose file</label>  ',
					//'      <input id="photo" type="file" accept="image/*"/><br/>', 
					'      <input id="photo" type="file" accept=".txt"/><br/>',
					'      <a>cancel</a>                                        ',
					'    </div>                                                 ',
					'</div>                                                     ',
				].join('\n');
				var input = g.root.querySelector("input");
				input.addEventListener('change', getPic);

				// prevent clicking in input or label from canceling
				input.addEventListener('click', preventOtherClicks);
				var label = g.root.querySelector("label");
				label.addEventListener('click', preventOtherClicks);

				// clicking cancel or outside cancels
				var cancel = g.root.querySelector("a");  // there's only one
				cancel.addEventListener('click', handleCancel);
				var getImage = g.root.querySelector(".getimage");
				getImage.addEventListener('click', handleCancel);

				// remember the original style
				g.rootDisplayStyle = g.root.style.display;

				window.document.body.appendChild(g.root);
			}

			// make it visible
			g.root.style.display = g.rootDisplayStyle;

			function preventOtherClicks(evt) {
				evt.stopPropagation();
			}

			function getPic(evt) {
				evt.stopPropagation();
				var fileInput = evt.target.files;
				if (!fileInput || !fileInput.length) {
					return sendError("no image selected");
				}

				var picURL = window.URL.createObjectURL(fileInput[0]);
				var img = new window.Image();

				//text/plain
				//image/bmp
				if (fileInput[0].type=="text/plain") {
					//str = "Text";
					var file = evt.target.files[0];  
					var reader = new FileReader();
					//reader.readAsText(file, 'CP1251');
					reader.readAsText(file);
					reader.onload = (function (file) {
						return function (e) {
							str = file.name;
							var r = e.target;
							sendResult(r.result);
						};
					})(file);

				} 
				//else {
              //str = "Image";
              //img.addEventListener('load', handleImageLoad);
              //img.addEventListener('error', handleImageError);
              //img.src = picURL;
              //}
			}

			function handleCancel(evt) {
				evt.stopPropagation();
				evt.preventDefault();
				sendError("cancelled");
			}

			function handleImageError(evt) {
				sendError("Could not get image");
			}

			function handleImageLoad(evt) {
				var img = evt.target;
				window.URL.revokeObjectURL(img.src);
				// We probably don't want the fullsize image. It might be 3000x2000 pixels or something too big
				g.ctx.canvas.width  = 256;
				g.ctx.canvas.height = 256;
				g.ctx.drawImage(img, 0, 0, g.ctx.canvas.width, g.ctx.canvas.height);

				var dataUrl = g.ctx.canvas.toDataURL(); 

				// free the canvas memory (could probably be zero)
				g.ctx.canvas.width  = 1;
				g.ctx.canvas.height = 1;

				sendResult(dataUrl);
				g.busy = false;
			}

			function sendError(msg) {
				sendResult("error: " + msg);
			}

			function hide() {
				g.root.style.display = "none";
			}

			function sendResult(result) {
				hide();
				g.busy = false;
				SendMessage(objectName, funcName, str+"| "+result);           
			}
		},
	};

	mergeInto(LibraryManager.library, getImage);


	var saveText1 = {SaveFile: function (str,strName){
			var textstr = Pointer_stringify(str);
			var textstr2 = Pointer_stringify(strName);
			var a = document.createElement("a");
			a.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(textstr));
			//a.setAttribute("href", "data:text/plain," + textstr);
			//a.setAttribute("href", "data:text/plain," + textstr.replace(/<br>/g, encodeURIComponent("\r\n"))); 
			a.setAttribute("download", textstr2);
			a.click();
		}};

	mergeInto(LibraryManager.library, saveText1);



	var copyText1 = {copyStringToClipboard: function (str) {
			var textToCopy = Pointer_stringify(str);

			var el = document.createElement('textarea');
			el.value = textToCopy;
			el.setAttribute('readonly', '');
			el.style.position = 'absolute';
			el.style.left = '-9999px';
			document.body.appendChild(el);
			el.select();
			try {
				document.execCommand('copy');
				//alert("Copied the text: " + textToCopy);
			} catch(err) {
				//alert("Can`t copy: " + textToCopy);
			}
			document.body.removeChild(el);
		}};

	mergeInto(LibraryManager.library, copyText1);



	mergeInto(LibraryManager.library, {

		pasteStringFromClipboard: function (objectNamePtr, sometext) {
			var objectName = Pointer_stringify(objectNamePtr);
			var sometext2 = Pointer_stringify(sometext);

			var Pp1 = 0;
			var Pp2 = sometext2.indexOf ("@");

			var sometext2Copy = sometext2.substring (Pp1, Pp2 - Pp1);

			//alert (sometext2Copy+"&");

			var pastedtext= prompt("Please paste here:", "");
			SendMessage(objectName, sometext2Copy, sometext2+"%"+pastedtext);
		},

	}); */
////////////////////////////////////////////////////////////////////////
